package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val sender: String, // "user" or "mia"
    val content: String,
    val emotion: String = "Serena",
    val touchFeedback: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)
