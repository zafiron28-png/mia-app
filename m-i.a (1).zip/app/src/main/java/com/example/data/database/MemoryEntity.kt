package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val category: String, // "perfil", "recuerdo", "emocion", "toque", "filosofia"
    val content: String,
    val emotionalState: String = "Serena",
    val timestamp: Long = System.currentTimeMillis()
)
