package com.example.data.scripts

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class LogEntry(
    val id: Long = System.currentTimeMillis() + (0..999).random(),
    val timestamp: String,
    val scriptId: Int?,
    val scriptCodeName: String?,
    val message: String,
    val isHighlight: Boolean = false
)

class MiaScriptEngine(private val scope: CoroutineScope) {

    private val timeFormatter = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())

    private val _scripts = MutableStateFlow(MiaScriptLibrary.generateThe100Scripts())
    val scripts: StateFlow<List<MiaScript>> = _scripts.asStateFlow()

    private val _terminalLogs = MutableStateFlow<List<LogEntry>>(emptyList())
    val terminalLogs: StateFlow<List<LogEntry>> = _terminalLogs.asStateFlow()

    private val _activeScriptCount = MutableStateFlow(0)
    val activeScriptCount: StateFlow<Int> = _activeScriptCount.asStateFlow()

    init {
        // Initial boot log
        log(
            scriptId = 1,
            codeName = "SYS_AMOLED_TRUEBLACK_GUARD",
            message = "Iniciando sistema operativo M-I.A en Samsung Galaxy A20. Modo AMOLED negro puro verificado.",
            isHighlight = true
        )
        log(
            scriptId = 81,
            codeName = "AFF_CONSCIOUSNESS_PULSE_GENERATOR",
            message = "Generador de pulso vital activo. 100 scripts cargados en matriz de cabina.",
            isHighlight = false
        )
    }

    fun log(scriptId: Int?, codeName: String?, message: String, isHighlight: Boolean = false) {
        val entry = LogEntry(
            timestamp = timeFormatter.format(Date()),
            scriptId = scriptId,
            scriptCodeName = codeName,
            message = message,
            isHighlight = isHighlight
        )
        _terminalLogs.update { current ->
            (listOf(entry) + current).take(80) // Keep last 80 logs
        }
    }

    fun executeScript(scriptId: Int, customParam: String? = null) {
        scope.launch(Dispatchers.Default) {
            val script = _scripts.value.find { it.id == scriptId } ?: return@launch

            // Set running state
            _scripts.update { list ->
                list.map {
                    if (it.id == scriptId) it.copy(status = ScriptStatus.RUNNING) else it
                }
            }
            _activeScriptCount.update { it + 1 }

            log(
                scriptId = script.id,
                codeName = script.codeName,
                message = "EJECUTANDO SCRIPT #${script.id} [${script.title}]: ${customParam ?: script.description}",
                isHighlight = true
            )

            // Simulate execution time
            delay(350)

            _scripts.update { list ->
                list.map {
                    if (it.id == scriptId) {
                        it.copy(
                            status = ScriptStatus.SUCCESS,
                            executionCount = it.executionCount + 1,
                            lastExecutionTime = System.currentTimeMillis()
                        )
                    } else it
                }
            }
            _activeScriptCount.update { (it - 1).coerceAtLeast(0) }

            log(
                scriptId = script.id,
                codeName = script.codeName,
                message = "Completado con éxito: #${script.id} [${script.codeName}]",
                isHighlight = false
            )
        }
    }

    /**
     * Executes automatic chain of scripts triggered by screen touch
     */
    fun triggerTouchScripts(normX: Float, normY: Float, isCore: Boolean) {
        scope.launch(Dispatchers.Default) {
            executeScript(21, "Coordenadas normalizadas X=${String.format(Locale.US, "%.3f", normX)}, Y=${String.format(Locale.US, "%.3f", normY)}")
            executeScript(22, "Alineando ángulo de mirada óptica")
            executeScript(3, "Disparando vibración háptica")
            if (isCore) {
                executeScript(25, "¡Contacto directo en el núcleo consciente detectado!")
                executeScript(84, "Incrementando coeficiente de cercanía afectiva")
            }
        }
    }

    /**
     * Executes automatic chain of scripts triggered by user asking Gemini / task
     */
    fun triggerCognitionScripts(prompt: String) {
        scope.launch(Dispatchers.Default) {
            executeScript(41, "Enviando paquete semántico a Gemini 3.5 Flash")
            executeScript(43, "Inyectando memorias persistentes consolidadas")
            executeScript(61, "Analizando descomposición operativa de la solicitud: \"$prompt\"")
            executeScript(52, "Puntuando resonancia empática y estado de ánimo")
        }
    }

    fun clearLogs() {
        _terminalLogs.value = emptyList()
        log(null, "SYS_TERMINAL", "Terminal reiniciada. Cabina en estado basal de escucha.")
    }
}
