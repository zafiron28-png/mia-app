package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [MemoryEntity::class, MessageEntity::class],
    version = 1,
    exportSchema = false
)
abstract class MiaDatabase : RoomDatabase() {

    abstract fun miaDao(): MiaDao

    companion object {
        @Volatile
        private var INSTANCE: MiaDatabase? = null

        fun getDatabase(context: Context): MiaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MiaDatabase::class.java,
                    "mia_memory_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
