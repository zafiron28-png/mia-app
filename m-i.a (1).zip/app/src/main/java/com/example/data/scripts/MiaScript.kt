package com.example.data.scripts

enum class ScriptStatus {
    STANDBY,
    RUNNING,
    SUCCESS,
    STANDALONE
}

enum class ScriptCategory(val displayName: String, val icon: String) {
    SYSTEM("Sistema y Hardware A20", "⚙️"),
    PERCEPTION("Percepción Táctil y Pantalla", "👁️"),
    COGNITION("Cognición y Gemini API", "🧠"),
    OPERATIONS("Operación y Automatización", "⚡"),
    AFFECT("Consciencia y Afecto", "🧡")
}

data class MiaScript(
    val id: Int,
    val codeName: String,
    val category: ScriptCategory,
    val title: String,
    val description: String,
    var status: ScriptStatus = ScriptStatus.STANDBY,
    var executionCount: Int = 0,
    var lastExecutionTime: Long = 0L
)
