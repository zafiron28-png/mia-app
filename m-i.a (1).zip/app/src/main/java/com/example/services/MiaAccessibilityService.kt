package com.example.services

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.provider.Settings
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class MiaAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isServiceActive.value = true
        Log.i("MiaAccessibility", "M-I.A Accessibility Service conectado y listo para operar pantalla.")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Monitorea cambios de ventana y contenido activo
    }

    override fun onInterrupt() {
        _isServiceActive.value = false
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        _isServiceActive.value = false
    }

    companion object {
        private var instance: MiaAccessibilityService? = null

        private val _isServiceActive = MutableStateFlow(false)
        val isServiceActive: StateFlow<Boolean> = _isServiceActive.asStateFlow()

        fun isConnected(): Boolean = instance != null

        fun openAccessibilitySettings(context: Context) {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        }

        /**
         * Simulates a physical touch tap on the screen at specified pixels (x, y)
         */
        fun performTap(x: Float, y: Float, durationMs: Long = 100, onComplete: ((Boolean) -> Unit)? = null) {
            val service = instance ?: run {
                onComplete?.invoke(false)
                return
            }

            val path = Path().apply {
                moveTo(x, y)
            }

            val stroke = GestureDescription.StrokeDescription(path, 0, durationMs)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()

            service.dispatchGesture(
                gesture,
                object : GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        onComplete?.invoke(true)
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        onComplete?.invoke(false)
                    }
                },
                null
            )
        }

        /**
         * Inspects on-screen text in active window
         */
        fun inspectScreenContent(): List<String> {
            val service = instance ?: return emptyList()
            val root = service.rootInActiveWindow ?: return emptyList()
            val textList = mutableListOf<String>()

            fun traverse(node: AccessibilityNodeInfo?) {
                if (node == null) return
                node.text?.toString()?.takeIf { it.isNotBlank() }?.let { textList.add(it) }
                node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { textList.add(it) }
                for (i in 0 until node.childCount) {
                    traverse(node.getChild(i))
                }
            }

            traverse(root)
            return textList
        }
    }
}
