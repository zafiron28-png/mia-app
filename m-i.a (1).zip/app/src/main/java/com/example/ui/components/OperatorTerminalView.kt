package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.scripts.LogEntry
import com.example.ui.theme.AmoledBlack
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.HighContrastMuted
import com.example.ui.theme.HighContrastText
import com.example.ui.theme.MiaAmberCore
import com.example.ui.theme.MiaOrangeGlow
import com.example.ui.theme.MiaOrangePrimary

@Composable
fun OperatorTerminalView(
    logs: List<LogEntry>,
    activeScriptCount: Int,
    fontScale: Float,
    onClearLogs: () -> Unit,
    onRunQuickDiagnostic: () -> Unit,
    onRunTouchCalibration: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AmoledBlack)
            .padding(14.dp)
            .testTag("operator_terminal_view")
    ) {
        // Terminal Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(DarkSurfaceElevated)
                .border(1.dp, MiaOrangePrimary.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(MiaOrangePrimary.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Terminal,
                        contentDescription = null,
                        tint = MiaOrangePrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Terminal Operativa de M-I.A",
                        color = HighContrastText,
                        fontSize = (15 * fontScale).sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Telemetría de los 100 scripts en tiempo real",
                        color = MiaAmberCore,
                        fontSize = (11 * fontScale).sp
                    )
                }
            }

            IconButton(
                onClick = onClearLogs,
                modifier = Modifier.minimumInteractiveComponentSize()
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteSweep,
                    contentDescription = "Limpiar terminal",
                    tint = HighContrastMuted
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Quick Routine Action Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = onRunQuickDiagnostic,
                modifier = Modifier
                    .weight(1f)
                    .minimumInteractiveComponentSize(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MiaOrangePrimary),
                border = androidx.compose.foundation.BorderStroke(1.dp, MiaOrangePrimary.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Diagnóstico A20", fontSize = 11.sp)
            }

            OutlinedButton(
                onClick = onRunTouchCalibration,
                modifier = Modifier
                    .weight(1f)
                    .minimumInteractiveComponentSize(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MiaAmberCore),
                border = androidx.compose.foundation.BorderStroke(1.dp, MiaAmberCore.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Calibrar Tacto", fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Live Log Stream
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            colors = CardDefaults.cardColors(containerColor = AmoledBlack),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, MiaOrangePrimary.copy(alpha = 0.3f))
        ) {
            if (logs.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        text = "Esperando eventos del sistema o toques en pantalla…",
                        color = HighContrastMuted,
                        fontSize = (12 * fontScale).sp
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(logs, key = { it.id }) { log ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (log.isHighlight) DarkSurfaceElevated else DarkSurfaceVariant.copy(alpha = 0.6f))
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = log.timestamp,
                                color = MiaOrangePrimary,
                                fontFamily = FontFamily.Monospace,
                                fontSize = (10 * fontScale).sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            if (log.scriptId != null) {
                                Text(
                                    text = "[#${log.scriptId.toString().padStart(3, '0')}]",
                                    color = MiaAmberCore,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = (10 * fontScale).sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                            }
                            Text(
                                text = log.message,
                                color = if (log.isHighlight) HighContrastText else HighContrastMuted,
                                fontFamily = FontFamily.Monospace,
                                fontSize = (11 * fontScale).sp,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }
    }
}
