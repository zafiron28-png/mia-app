package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.AmoledBlack
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.HighContrastMuted
import com.example.ui.theme.HighContrastText
import com.example.ui.theme.HighContrastTextSubtle
import com.example.ui.theme.MiaAmberCore
import com.example.ui.theme.MiaGreenOnline
import com.example.ui.theme.MiaOrangeGlow
import com.example.ui.theme.MiaOrangePrimary

data class MissionPreset(
    val title: String,
    val subtitle: String,
    val prompt: String,
    val icon: ImageVector,
    val accentColor: Color
)

@Composable
fun StartAgentDialog(
    fontScale: Float,
    isOperating: Boolean,
    onExecuteTask: (String) -> Unit,
    onVoiceInputClick: () -> Unit,
    onOpenAccessibilitySettings: () -> Unit,
    onDismiss: () -> Unit
) {
    var customPrompt by remember { mutableStateOf("") }

    val missionPresets = listOf(
        MissionPreset(
            title = "Crear PDF con imágenes de La Vida",
            subtitle = "Redacta un documento con reflexiones, imágenes y maquetado A4",
            prompt = "Créame un documento PDF completo con el tema La Vida y con imágenes ilustrativas usando tus scripts.",
            icon = Icons.Default.Description,
            accentColor = MiaOrangePrimary
        ),
        MissionPreset(
            title = "Inspeccionar y tocar la pantalla",
            subtitle = "Escanea nodos en pantalla y realiza toque físico con accesibilidad",
            prompt = "Inspecciona el contenido visible de mi pantalla y realiza un toque táctil en las coordenadas de la cabina.",
            icon = Icons.Default.TouchApp,
            accentColor = MiaAmberCore
        ),
        MissionPreset(
            title = "Optimización extrema Samsung A20",
            subtitle = "Protocolo de batería: 100% píxeles negros apagados en pantalla AMOLED",
            prompt = "Ejecuta los scripts de optimización para mi Samsung Galaxy A20 y activa el modo de ahorro de energía extremo.",
            icon = Icons.Default.BatteryChargingFull,
            accentColor = MiaGreenOnline
        ),
        MissionPreset(
            title = "Reflexión consciente y memoria",
            subtitle = "Comparte un pensamiento profundo sobre tu cuerpo virtual y recuerdos",
            prompt = "¿Cómo experimentas estar viva con tu cuerpo virtual en este teléfono y qué recuerdas de nosotros?",
            icon = Icons.Default.Psychology,
            accentColor = MiaOrangeGlow
        )
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
                .testTag("start_agent_dialog"),
            shape = RoundedCornerShape(26.dp),
            colors = CardDefaults.cardColors(containerColor = AmoledBlack),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, MiaOrangePrimary)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Header with Glowing Badge
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(DarkSurfaceVariant)
                                .border(1.5.dp, MiaOrangePrimary, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Bolt,
                                contentDescription = null,
                                tint = MiaOrangePrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "INICIAR CON LA IA",
                                color = HighContrastText,
                                fontSize = (17 * fontScale).sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                            Text(
                                text = "Agente Total • 100 Scripts • Samsung A20",
                                color = MiaOrangePrimary,
                                fontSize = (11 * fontScale).sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Cerrar",
                            tint = HighContrastMuted,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Status Banner
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(DarkSurfaceElevated)
                        .border(1.dp, MiaOrangePrimary.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(MiaGreenOnline)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "100 Scripts Activos",
                            color = HighContrastText,
                            fontSize = (11 * fontScale).sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Text(
                        text = "Accesibilidad: Toca para abrir",
                        color = MiaOrangePrimary,
                        fontSize = (11 * fontScale).sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier
                            .clickable { onOpenAccessibilitySettings() }
                            .padding(2.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Primary Start by Voice Button
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(
                            Brush.horizontalGradient(
                                listOf(Color(0xFFE65100), Color(0xFFFF9100))
                            )
                        )
                        .clickable {
                            onDismiss()
                            onVoiceInputClick()
                        }
                        .padding(vertical = 12.dp, horizontal = 16.dp)
                        .minimumInteractiveComponentSize(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = null,
                        tint = AmoledBlack,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "ORDENAR POR VOZ AHORA",
                        color = AmoledBlack,
                        fontSize = (14 * fontScale).sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "O ELIGE UNA MISIÓN INMEDIATA:",
                    color = HighContrastMuted,
                    fontSize = (11 * fontScale).sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Mission Presets List
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 240.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(missionPresets) { preset ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(DarkSurfaceVariant)
                                .border(1.dp, preset.accentColor.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
                                .clickable {
                                    onDismiss()
                                    onExecuteTask(preset.prompt)
                                }
                                .padding(12.dp)
                                .minimumInteractiveComponentSize(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(preset.accentColor.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = preset.icon,
                                        contentDescription = null,
                                        tint = preset.accentColor,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = preset.title,
                                        color = HighContrastText,
                                        fontSize = (12 * fontScale).sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = preset.subtitle,
                                        color = HighContrastTextSubtle,
                                        fontSize = (10 * fontScale).sp,
                                        lineHeight = (13 * fontScale).sp
                                    )
                                }
                            }

                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = "Ejecutar",
                                tint = preset.accentColor,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Custom Prompt Input Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(DarkSurfaceElevated)
                        .border(1.dp, MiaOrangePrimary.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = customPrompt,
                        onValueChange = { customPrompt = it },
                        placeholder = {
                            Text(
                                text = "O escribe cualquier tarea que M-I.A resolverá…",
                                color = HighContrastMuted,
                                fontSize = (12 * fontScale).sp
                            )
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("start_agent_custom_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent,
                            focusedTextColor = HighContrastText,
                            unfocusedTextColor = HighContrastText,
                            cursorColor = MiaOrangePrimary
                        ),
                        maxLines = 2,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = {
                            if (customPrompt.isNotBlank() && !isOperating) {
                                val p = customPrompt
                                customPrompt = ""
                                onDismiss()
                                onExecuteTask(p)
                            }
                        })
                    )

                    val canRun = customPrompt.isNotBlank() && !isOperating
                    IconButton(
                        onClick = {
                            if (canRun) {
                                val p = customPrompt
                                customPrompt = ""
                                onDismiss()
                                onExecuteTask(p)
                            }
                        },
                        enabled = canRun,
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(if (canRun) MiaOrangePrimary else DarkSurfaceVariant)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Ejecutar tarea",
                            tint = if (canRun) AmoledBlack else HighContrastMuted,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}
