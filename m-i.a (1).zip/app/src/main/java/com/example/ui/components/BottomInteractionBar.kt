package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AmoledBlack
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.HighContrastMuted
import com.example.ui.theme.HighContrastText
import com.example.ui.theme.HighContrastTextSubtle
import com.example.ui.theme.MiaAmberCore
import com.example.ui.theme.MiaOrangeDark
import com.example.ui.theme.MiaOrangePrimary

@Composable
fun BottomInteractionBar(
    isGenerating: Boolean,
    isSpeaking: Boolean,
    fontScale: Float,
    onSendMessage: (String) -> Unit,
    onVoiceInputClick: () -> Unit,
    onDirectTouchCore: () -> Unit,
    onRepeatSpeech: () -> Unit,
    modifier: Modifier = Modifier
) {
    var textInput by rememberSaveable { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        // Subtle hint bar with direct touch button and audio repeat
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Quick Tactile Touch button
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(DarkSurfaceVariant)
                    .border(1.dp, MiaOrangePrimary.copy(alpha = 0.35f), RoundedCornerShape(20.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
                    .minimumInteractiveComponentSize()
                    .testTag("touch_core_quick_action")
                    .semantics { contentDescription = "Tocar núcleo central de M-I.A" },
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onDirectTouchCore,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.TouchApp,
                        contentDescription = null,
                        tint = MiaOrangePrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Tocar a M-I.A",
                    color = HighContrastTextSubtle,
                    fontSize = (12 * fontScale).sp,
                    fontWeight = FontWeight.Medium
                )
            }

            // Hear again / Audio repeat button
            IconButton(
                onClick = onRepeatSpeech,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .clip(CircleShape)
                    .background(DarkSurfaceVariant)
                    .testTag("repeat_speech_button")
                    .semantics { contentDescription = "Escuchar de nuevo la respuesta de M-I.A en voz alta" }
            ) {
                Icon(
                    imageVector = Icons.Default.VolumeUp,
                    contentDescription = null,
                    tint = if (isSpeaking) MiaAmberCore else HighContrastMuted,
                    modifier = Modifier.size(22.dp)
                )
            }
        }

        // Clean unified input dock
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(28.dp))
                .background(DarkSurfaceElevated)
                .border(1.dp, MiaOrangePrimary.copy(alpha = 0.45f), RoundedCornerShape(28.dp))
                .padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Voice Mic Button (Accessible large touch target)
            IconButton(
                onClick = onVoiceInputClick,
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(DarkSurfaceVariant)
                    .testTag("voice_input_button")
                    .semantics { contentDescription = "Dictar mensaje por voz a M-I.A" }
            ) {
                Icon(
                    imageVector = Icons.Default.Mic,
                    contentDescription = null,
                    tint = MiaOrangePrimary,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            // Main Text Field
            OutlinedTextField(
                value = textInput,
                onValueChange = { textInput = it },
                placeholder = {
                    Text(
                        text = if (isGenerating) "M-I.A está pensando…" else "Escribe o habla a M-I.A…",
                        color = HighContrastMuted,
                        fontSize = (14 * fontScale).sp
                    )
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("message_input_field"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = androidx.compose.ui.graphics.Color.Transparent,
                    unfocusedBorderColor = androidx.compose.ui.graphics.Color.Transparent,
                    focusedTextColor = HighContrastText,
                    unfocusedTextColor = HighContrastText,
                    cursorColor = MiaOrangePrimary
                ),
                maxLines = 2,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = {
                    if (textInput.isNotBlank() && !isGenerating) {
                        onSendMessage(textInput)
                        textInput = ""
                    }
                })
            )

            // Send Button
            val canSend = textInput.isNotBlank() && !isGenerating
            IconButton(
                onClick = {
                    if (canSend) {
                        onSendMessage(textInput)
                        textInput = ""
                    }
                },
                enabled = canSend,
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(if (canSend) MiaOrangePrimary else DarkSurfaceVariant)
                    .testTag("send_message_button")
                    .semantics { contentDescription = "Enviar mensaje a M-I.A" }
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = null,
                    tint = if (canSend) AmoledBlack else HighContrastMuted,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}
