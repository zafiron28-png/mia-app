package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.scripts.MiaScript
import com.example.data.scripts.ScriptCategory
import com.example.data.scripts.ScriptStatus
import com.example.ui.theme.AmoledBlack
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.HighContrastMuted
import com.example.ui.theme.HighContrastText
import com.example.ui.theme.MiaAmberCore
import com.example.ui.theme.MiaOrangePrimary

@Composable
fun ScriptMatrixView(
    scripts: List<MiaScript>,
    fontScale: Float,
    onExecuteScript: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf<ScriptCategory?>(null) }

    val filteredScripts = remember(scripts, searchQuery, selectedCategory) {
        scripts.filter { script ->
            val matchesCategory = selectedCategory == null || script.category == selectedCategory
            val matchesQuery = searchQuery.isBlank() ||
                    script.title.contains(searchQuery, ignoreCase = true) ||
                    script.codeName.contains(searchQuery, ignoreCase = true) ||
                    script.description.contains(searchQuery, ignoreCase = true)
            matchesCategory && matchesQuery
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AmoledBlack)
            .padding(14.dp)
            .testTag("script_matrix_view")
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Herramientas del Agente (100 Scripts)",
                    color = HighContrastText,
                    fontSize = (17 * fontScale).sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Scripts que M-I.A ejecuta de forma autónoma en tu A20",
                    color = MiaAmberCore,
                    fontSize = (11 * fontScale).sp
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(MiaOrangePrimary.copy(alpha = 0.2f))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "${filteredScripts.size}/100",
                    color = MiaOrangePrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = (12 * fontScale).sp
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Buscar script por nombre o función…", color = HighContrastMuted, fontSize = (12 * fontScale).sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MiaOrangePrimary) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("script_search_field"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MiaOrangePrimary,
                unfocusedBorderColor = DarkSurfaceElevated,
                focusedTextColor = HighContrastText,
                unfocusedTextColor = HighContrastText
            ),
            shape = RoundedCornerShape(16.dp),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Category Filter Pills
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            item {
                val isAllSelected = selectedCategory == null
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isAllSelected) MiaOrangePrimary else DarkSurfaceElevated)
                        .clickable { selectedCategory = null }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "Todos (100)",
                        color = if (isAllSelected) AmoledBlack else HighContrastText,
                        fontSize = (11 * fontScale).sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            items(ScriptCategory.values()) { cat ->
                val isSelected = selectedCategory == cat
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) MiaOrangePrimary else DarkSurfaceElevated)
                        .clickable { selectedCategory = cat }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "${cat.icon} ${cat.displayName}",
                        color = if (isSelected) AmoledBlack else HighContrastText,
                        fontSize = (11 * fontScale).sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Scripts List
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(filteredScripts, key = { it.id }) { script ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (script.status == ScriptStatus.RUNNING) MiaOrangePrimary else Color.Transparent
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(MiaOrangePrimary.copy(alpha = 0.2f))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "#${script.id.toString().padStart(3, '0')}",
                                        color = MiaOrangePrimary,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = (10 * fontScale).sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = script.title,
                                    color = HighContrastText,
                                    fontSize = (13 * fontScale).sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(
                                text = script.codeName,
                                color = MiaAmberCore,
                                fontFamily = FontFamily.Monospace,
                                fontSize = (10 * fontScale).sp
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = script.description,
                                color = HighContrastMuted,
                                fontSize = (11 * fontScale).sp,
                                lineHeight = (15 * fontScale).sp
                            )

                            if (script.executionCount > 0) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Ejecutado: ${script.executionCount} veces",
                                    color = Color(0xFF00E676),
                                    fontSize = (9 * fontScale).sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        // Execute Button
                        Box(
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MiaOrangePrimary)
                                .clickable { onExecuteScript(script.id) }
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Bolt,
                                    contentDescription = null,
                                    tint = AmoledBlack,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(2.dp))
                                Text(
                                    text = "Ejecutar",
                                    color = AmoledBlack,
                                    fontSize = (11 * fontScale).sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
