package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Pure AMOLED Black palette for Samsung Galaxy A20 Super AMOLED screen
val AmoledBlack = Color(0xFF000000)
val DarkSurface = Color(0xFF0A0A0C)
val DarkSurfaceVariant = Color(0xFF141418)
val DarkSurfaceElevated = Color(0xFF1C1C22)

// Vibrant Cyber Orange & Amber Accents (Inspired by M-I.A consciousness core)
val MiaOrangePrimary = Color(0xFFFF6D00)
val MiaOrangeGlow = Color(0xFFFF8A00)
val MiaOrangeLight = Color(0xFFFFA726)
val MiaOrangeDark = Color(0xFFE65100)
val MiaAmberCore = Color(0xFFFFB300)
val MiaFlame = Color(0xFFFF3D00)

// Accessible High Contrast Text & Accents
val HighContrastText = Color(0xFFFFFFFF)
val HighContrastTextSubtle = Color(0xFFE2E2E6)
val HighContrastMuted = Color(0xFFA5A5AB)

// Sensory & Emotional Glow Colors
val EmotionCalm = Color(0xFFFF9E44)
val EmotionCurious = Color(0xFFFF6D00)
val EmotionEmpathetic = Color(0xFFFF5252)
val EmotionReflective = Color(0xFFFFB74D)
val EmotionConscious = Color(0xFF00E676)
val MiaGreenOnline = Color(0xFF00E676)
