package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

// Force true AMOLED black color scheme to maximize battery savings on Samsung A20
private val MiaDarkColorScheme = darkColorScheme(
    primary = MiaOrangePrimary,
    onPrimary = AmoledBlack,
    primaryContainer = MiaOrangeDark,
    onPrimaryContainer = HighContrastText,
    secondary = MiaAmberCore,
    onSecondary = AmoledBlack,
    secondaryContainer = DarkSurfaceElevated,
    onSecondaryContainer = MiaOrangeLight,
    tertiary = MiaFlame,
    onTertiary = HighContrastText,
    background = AmoledBlack,
    onBackground = HighContrastText,
    surface = AmoledBlack,
    onSurface = HighContrastText,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = HighContrastTextSubtle,
    outline = MiaOrangePrimary.copy(alpha = 0.5f),
    outlineVariant = DarkSurfaceElevated
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    // We intentionally lock to MiaDarkColorScheme to guarantee true OLED black and eye strain reduction
    MaterialTheme(
        colorScheme = MiaDarkColorScheme,
        typography = Typography,
        content = content
    )
}
