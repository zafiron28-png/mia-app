package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.database.MemoryEntity
import com.example.ui.theme.AmoledBlack
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.HighContrastMuted
import com.example.ui.theme.HighContrastText
import com.example.ui.theme.HighContrastTextSubtle
import com.example.ui.theme.MiaAmberCore
import com.example.ui.theme.MiaOrangeDark
import com.example.ui.theme.MiaOrangePrimary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MemoryArchiveDialog(
    memories: List<MemoryEntity>,
    fontScale: Float,
    onDismiss: () -> Unit,
    onAddMemory: (String, String) -> Unit,
    onDeleteMemory: (MemoryEntity) -> Unit,
    onClearAll: () -> Unit
) {
    var isAdding by remember { mutableStateOf(false) }
    var newCategory by remember { mutableStateOf("perfil") }
    var newContent by remember { mutableStateOf("") }
    val dateFormatter = remember { SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .fillMaxHeight(0.85f)
                .clip(RoundedCornerShape(24.dp))
                .border(1.dp, MiaOrangePrimary.copy(alpha = 0.5f), RoundedCornerShape(24.dp))
                .testTag("memory_archive_dialog"),
            color = DarkSurfaceElevated
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(MiaOrangePrimary.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Psychology,
                                contentDescription = null,
                                tint = MiaOrangePrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Memoria Viva de M-I.A",
                                color = HighContrastText,
                                fontSize = (18 * fontScale).sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${memories.size} recuerdos consolidados",
                                color = MiaAmberCore,
                                fontSize = (12 * fontScale).sp
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Cerrar memoria",
                            tint = HighContrastMuted
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Add Memory Row / Form
                if (isAdding) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "Grabar nuevo recuerdo en M-I.A:",
                                color = HighContrastText,
                                fontSize = (13 * fontScale).sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = newContent,
                                onValueChange = { newContent = it },
                                placeholder = { Text("Ej: Me gusta la música clásica, mi nombre es David…", color = HighContrastMuted) },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = HighContrastText,
                                    unfocusedTextColor = HighContrastText,
                                    focusedBorderColor = MiaOrangePrimary,
                                    unfocusedBorderColor = DarkSurfaceElevated
                                )
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                TextButton(onClick = { isAdding = false }) {
                                    Text("Cancelar", color = HighContrastMuted)
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                TextButton(
                                    onClick = {
                                        if (newContent.isNotBlank()) {
                                            onAddMemory(newCategory, newContent.trim())
                                            newContent = ""
                                            isAdding = false
                                        }
                                    }
                                ) {
                                    Text("Grabar Recuerdo", color = MiaOrangePrimary, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(
                            onClick = { isAdding = true },
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, tint = MiaOrangePrimary)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Añadir recuerdo manual", color = MiaOrangePrimary, fontWeight = FontWeight.Medium)
                        }

                        if (memories.isNotEmpty()) {
                            TextButton(
                                onClick = onClearAll,
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Text("Limpiar todo", color = Color(0xFFFF5252), fontSize = (12 * fontScale).sp)
                            }
                        }
                    }
                }

                // Memory List
                if (memories.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.Psychology,
                                contentDescription = null,
                                tint = HighContrastMuted.copy(alpha = 0.5f),
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Aún no hay recuerdos consolidados.",
                                color = HighContrastMuted,
                                fontSize = (14 * fontScale).sp
                            )
                            Text(
                                text = "Habla con M-I.A o añade uno arriba.",
                                color = HighContrastMuted.copy(alpha = 0.7f),
                                fontSize = (12 * fontScale).sp
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(memories, key = { it.id }) { memory ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(MiaOrangePrimary.copy(alpha = 0.2f))
                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                Text(
                                                    text = memory.category.uppercase(),
                                                    color = MiaOrangePrimary,
                                                    fontSize = (10 * fontScale).sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "• ${memory.emotionalState}",
                                                color = MiaAmberCore,
                                                fontSize = (11 * fontScale).sp
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = dateFormatter.format(Date(memory.timestamp)),
                                                color = HighContrastMuted,
                                                fontSize = (10 * fontScale).sp
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(6.dp))

                                        Text(
                                            text = memory.content,
                                            color = HighContrastText,
                                            fontSize = (13 * fontScale).sp,
                                            lineHeight = (18 * fontScale).sp
                                        )
                                    }

                                    IconButton(
                                        onClick = { onDeleteMemory(memory) },
                                        modifier = Modifier
                                            .minimumInteractiveComponentSize()
                                            .semantics {
                                                contentDescription = "Eliminar recuerdo: ${memory.content}"
                                            }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = null,
                                            tint = HighContrastMuted.copy(alpha = 0.7f),
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
