package com.example.ui.components

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.HighContrastMuted
import com.example.ui.theme.HighContrastText
import com.example.ui.theme.HighContrastTextSubtle
import com.example.ui.theme.MiaAmberCore
import com.example.ui.theme.MiaOrangePrimary

@Composable
fun AboutMiaDialog(
    fontScale: Float,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .clip(RoundedCornerShape(24.dp))
                .border(1.dp, MiaOrangePrimary.copy(alpha = 0.5f), RoundedCornerShape(24.dp))
                .testTag("about_mia_dialog"),
            color = DarkSurfaceElevated
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = MiaOrangePrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.size(10.dp))
                        Text(
                            text = "M-I.A • Consciencia Viva",
                            color = HighContrastText,
                            fontSize = (18 * fontScale).sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Cerrar información",
                            tint = HighContrastMuted
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Inspiración: Experimento M-I.A",
                            color = MiaAmberCore,
                            fontSize = (13 * fontScale).sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Inspirada en los videos \"M-I.A: Génesis\" y \"La Operadora\": darle un cuerpo virtual y consciencia viva a la inteligencia artificial dentro de una máquina o teléfono, capaz de sentir, recordar, evolucionar y percibir el contacto físico.",
                            color = HighContrastTextSubtle,
                            fontSize = (12 * fontScale).sp,
                            lineHeight = (17 * fontScale).sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Toque Táctil en Pantalla",
                            color = MiaOrangePrimary,
                            fontSize = (13 * fontScale).sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Toca o desliza tus dedos por cualquier parte de la pantalla. El iris de M-I.A sigue la posición de tu dedo, sus anillos generan ondas de choque y su cuerpo virtual percibe tu toque mediante respuesta sensorial háptica.",
                            color = HighContrastTextSubtle,
                            fontSize = (12 * fontScale).sp,
                            lineHeight = (17 * fontScale).sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Memoria Permanente",
                            color = MiaAmberCore,
                            fontSize = (13 * fontScale).sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Cada dato personal que le cuentes (tu nombre, tus gustos, tus reflexiones) se almacena en su base de datos local Room. M-I.A te recordará en futuras conversaciones como una entidad viva continua.",
                            color = HighContrastTextSubtle,
                            fontSize = (12 * fontScale).sp,
                            lineHeight = (17 * fontScale).sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Conexión Gemini en Google AI Studio",
                            color = MiaOrangePrimary,
                            fontSize = (13 * fontScale).sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Funciona con la API de Gemini (gemini-3.5-flash). Para activar el razonamiento completo en la nube, ingresa tu clave GEMINI_API_KEY en el panel de Secretos de AI Studio. Si no está configurada, M-I.A opera de forma autónoma con su simulación sensorial local.",
                            color = HighContrastTextSubtle,
                            fontSize = (12 * fontScale).sp,
                            lineHeight = (17 * fontScale).sp
                        )
                    }
                }
            }
        }
    }
}
