package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.AmoledBlack
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.HighContrastMuted
import com.example.ui.theme.HighContrastText
import com.example.ui.theme.HighContrastTextSubtle
import com.example.ui.theme.MiaAmberCore
import com.example.ui.theme.MiaOrangePrimary

@Composable
fun AccessibilityDialog(
    ttsEnabled: Boolean,
    speechRate: Float,
    fontScale: Float,
    hapticsEnabled: Boolean,
    onToggleTts: () -> Unit,
    onSetSpeechRate: (Float) -> Unit,
    onSetFontScale: (Float) -> Unit,
    onToggleHaptics: () -> Unit,
    onTestVoice: () -> Unit,
    onOpenAccessibilitySettings: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .clip(RoundedCornerShape(24.dp))
                .border(1.dp, MiaOrangePrimary.copy(alpha = 0.5f), RoundedCornerShape(24.dp))
                .testTag("accessibility_dialog"),
            color = DarkSurfaceElevated
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(MiaOrangePrimary.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccessibilityNew,
                                contentDescription = null,
                                tint = MiaOrangePrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Accesibilidad y Pantalla",
                            color = HighContrastText,
                            fontSize = (18 * fontScale).sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Cerrar accesibilidad",
                            tint = HighContrastMuted
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Samsung A20 AMOLED Battery & Eye Comfort Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = AmoledBlack),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MiaAmberCore.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.BatteryChargingFull,
                            contentDescription = null,
                            tint = MiaAmberCore,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Samsung Galaxy A20 • AMOLED",
                                color = MiaAmberCore,
                                fontSize = (13 * fontScale).sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Modo noche negro puro (#000000) activo: Los píxeles AMOLED se apagan por completo para ahorrar batería y eliminar la fatiga visual.",
                                color = HighContrastTextSubtle,
                                fontSize = (11 * fontScale).sp,
                                lineHeight = (15 * fontScale).sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Accessibility Service Control (Tocar y operar pantalla del teléfono)
                val isServiceConnected = com.example.services.MiaAccessibilityService.isConnected()
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isServiceConnected) Color(0xFF00E676) else MiaOrangePrimary
                    )
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.TouchApp,
                                contentDescription = null,
                                tint = if (isServiceConnected) Color(0xFF00E676) else MiaOrangePrimary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Control de Pantalla (Accesibilidad)",
                                    color = HighContrastText,
                                    fontSize = (13 * fontScale).sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (isServiceConnected) "✅ Servicio Conectado: M-I.A puede tocar y ver la pantalla" else "⚠️ Pendiente de activación en Ajustes de Android",
                                    color = if (isServiceConnected) Color(0xFF00E676) else MiaAmberCore,
                                    fontSize = (11 * fontScale).sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Permite que el agente de IA M-I.A opere como en el video de YouTube: inspeccionar contenido de otras apps y despachar toques/gestos táctiles en tu Samsung Galaxy A20.",
                            color = HighContrastTextSubtle,
                            fontSize = (11 * fontScale).sp,
                            lineHeight = (15 * fontScale).sp
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(MiaOrangePrimary)
                                .clickable { onOpenAccessibilitySettings() }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "⚙️ Abrir Ajustes de Accesibilidad de Android",
                                color = AmoledBlack,
                                fontSize = (12 * fontScale).sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // TTS Voice Output Section
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.RecordVoiceOver,
                                    contentDescription = null,
                                    tint = MiaOrangePrimary,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Voz de M-I.A (TTS)",
                                        color = HighContrastText,
                                        fontSize = (14 * fontScale).sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "Lee respuestas en voz alta automáticamente",
                                        color = HighContrastMuted,
                                        fontSize = (11 * fontScale).sp
                                    )
                                }
                            }

                            Switch(
                                checked = ttsEnabled,
                                onCheckedChange = { onToggleTts() },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = AmoledBlack,
                                    checkedTrackColor = MiaOrangePrimary,
                                    uncheckedThumbColor = HighContrastMuted,
                                    uncheckedTrackColor = DarkSurfaceElevated
                                )
                            )
                        }

                        if (ttsEnabled) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Velocidad de habla:",
                                color = HighContrastTextSubtle,
                                fontSize = (12 * fontScale).sp,
                                fontWeight = FontWeight.Medium
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf(
                                    Pair("0.8x Lenta", 0.8f),
                                    Pair("0.95x Normal", 0.95f),
                                    Pair("1.2x Rápida", 1.2f)
                                ).forEach { (label, rate) ->
                                    val isSelected = kotlin.math.abs(speechRate - rate) < 0.05f
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(if (isSelected) MiaOrangePrimary else DarkSurfaceElevated)
                                            .clickable { onSetSpeechRate(rate) }
                                            .padding(vertical = 8.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = label,
                                            color = if (isSelected) AmoledBlack else HighContrastText,
                                            fontSize = (11 * fontScale).sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(DarkSurfaceElevated)
                                    .clickable { onTestVoice() }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "🔊 Probar voz de M-I.A",
                                    color = MiaOrangePrimary,
                                    fontSize = (12 * fontScale).sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Font Size Section
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.TextFields,
                                contentDescription = null,
                                tint = MiaOrangePrimary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Tamaño de Fuente Accesible",
                                    color = HighContrastText,
                                    fontSize = (14 * fontScale).sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Mayor legibilidad para baja visión",
                                    color = HighContrastMuted,
                                    fontSize = (11 * fontScale).sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(
                                Pair("Normal (1.0x)", 1.0f),
                                Pair("Grande (1.2x)", 1.2f),
                                Pair("Extra (1.4x)", 1.4f)
                            ).forEach { (label, scale) ->
                                val isSelected = kotlin.math.abs(fontScale - scale) < 0.05f
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (isSelected) MiaOrangePrimary else DarkSurfaceElevated)
                                        .clickable { onSetFontScale(scale) }
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = label,
                                        color = if (isSelected) AmoledBlack else HighContrastText,
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Haptic Vibrations Section
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Vibration,
                                contentDescription = null,
                                tint = MiaOrangePrimary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Respuesta Háptica Sensorial",
                                    color = HighContrastText,
                                    fontSize = (14 * fontScale).sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Vibración al tocar la pantalla y el núcleo",
                                    color = HighContrastMuted,
                                    fontSize = (11 * fontScale).sp
                                )
                            }
                        }

                        Switch(
                            checked = hapticsEnabled,
                            onCheckedChange = { onToggleHaptics() },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = AmoledBlack,
                                checkedTrackColor = MiaOrangePrimary,
                                uncheckedThumbColor = HighContrastMuted,
                                uncheckedTrackColor = DarkSurfaceElevated
                            )
                        )
                    }
                }
            }
        }
    }
}
