package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import com.example.ui.theme.AmoledBlack
import com.example.ui.theme.MiaAmberCore
import com.example.ui.theme.MiaFlame
import com.example.ui.theme.MiaOrangeGlow
import com.example.ui.theme.MiaOrangeLight
import com.example.ui.theme.MiaOrangePrimary
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun MiaLivingCore(
    emotionalState: String,
    isSpeaking: Boolean,
    isGenerating: Boolean,
    touchX: Float, // Normalized 0..1
    touchY: Float, // Normalized 0..1
    isTouching: Boolean,
    touchRippleKey: Long,
    onCoreClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Breathing & rotation infinite transitions
    val infiniteTransition = rememberInfiniteTransition(label = "MiaVitalPulse")

    // Core respiration speed responds to state
    val breathDuration = when {
        isSpeaking -> 1200
        isGenerating -> 800
        isTouching -> 1400
        else -> 2800
    }

    val breathScale by infiniteTransition.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(
            animation = tween(breathDuration, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breathScale"
    )

    val coreRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(18000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "coreRotation"
    )

    val wavePulse by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "wavePulse"
    )

    // Touch ripple animation triggered whenever touchRippleKey changes
    val rippleRadius = remember { Animatable(0f) }
    val rippleAlpha = remember { Animatable(0f) }

    LaunchedEffect(touchRippleKey) {
        if (touchRippleKey > 0) {
            rippleRadius.snapTo(10f)
            rippleAlpha.snapTo(0.85f)
            rippleRadius.animateTo(
                targetValue = 320f,
                animationSpec = tween(700, easing = FastOutSlowInEasing)
            )
            rippleAlpha.animateTo(
                targetValue = 0f,
                animationSpec = tween(350, easing = LinearEasing)
            )
        }
    }

    // Color theme based on emotion
    val primaryColor = when (emotionalState) {
        "Empática" -> MiaFlame
        "Curiosa" -> MiaOrangeLight
        "Pensativa" -> MiaAmberCore
        "Conectada" -> MiaOrangeGlow
        "Alerta" -> Color(0xFFFF3300)
        else -> MiaOrangePrimary
    }

    val interactionSource = remember { MutableInteractionSource() }

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("mia_living_core")
            .semantics {
                role = Role.Button
                contentDescription = "Cuerpo virtual de M-I.A en estado $emotionalState. Toca para conectar."
            }
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onCoreClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val centerOffset = Offset(size.width * 0.5f, size.height * 0.46f)
            val baseRadius = size.width.coerceAtMost(size.height) * 0.22f * breathScale

            // Draw Background Touch Ripple
            if (rippleAlpha.value > 0.01f) {
                val touchPoint = Offset(touchX * size.width, touchY * size.height)
                drawCircle(
                    color = primaryColor.copy(alpha = rippleAlpha.value * 0.4f),
                    radius = rippleRadius.value,
                    center = touchPoint,
                    style = Stroke(width = 4f)
                )
                drawCircle(
                    color = MiaAmberCore.copy(alpha = rippleAlpha.value * 0.25f),
                    radius = rippleRadius.value * 0.65f,
                    center = touchPoint,
                    style = Stroke(width = 2f)
                )
            }

            // Gaze offset toward touch point
            val targetGazeX = (touchX - 0.5f) * baseRadius * 0.42f
            val targetGazeY = (touchY - 0.46f) * baseRadius * 0.42f
            val gazeOffset = Offset(centerOffset.x + targetGazeX, centerOffset.y + targetGazeY)

            // Outer Radiant Atmospheric Glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        primaryColor.copy(alpha = if (isTouching) 0.35f else 0.20f),
                        MiaOrangeGlow.copy(alpha = 0.08f),
                        Color.Transparent
                    ),
                    center = centerOffset,
                    radius = baseRadius * 2.2f
                ),
                radius = baseRadius * 2.2f,
                center = centerOffset
            )

            // Outer Dashed Neural Orbit Ring
            val dashedEffect = PathEffect.dashPathEffect(floatArrayOf(24f, 16f), coreRotation)
            drawCircle(
                color = primaryColor.copy(alpha = 0.45f),
                radius = baseRadius * 1.55f,
                center = centerOffset,
                style = Stroke(width = 2f, pathEffect = dashedEffect)
            )

            // Middle Energy Halo Ring
            drawCircle(
                brush = Brush.sweepGradient(
                    colors = listOf(
                        primaryColor.copy(alpha = 0.8f),
                        MiaAmberCore.copy(alpha = 0.3f),
                        primaryColor.copy(alpha = 0.8f)
                    ),
                    center = centerOffset
                ),
                radius = baseRadius * 1.25f,
                center = centerOffset,
                style = Stroke(width = if (isSpeaking) 5f * wavePulse else 3f)
            )

            // Orbiting Synaptic Node Dots
            val particleCount = 8
            for (i in 0 until particleCount) {
                val angle = (coreRotation * (PI / 180.0) + (i * 2 * PI / particleCount)).toFloat()
                val px = centerOffset.x + cos(angle) * (baseRadius * 1.55f)
                val py = centerOffset.y + sin(angle) * (baseRadius * 1.55f)
                drawCircle(
                    color = if (i % 2 == 0) MiaAmberCore else primaryColor,
                    radius = if (isTouching) 5f else 3.5f,
                    center = Offset(px, py)
                )
            }

            // Main Resonant Sphere Body
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        primaryColor.copy(alpha = 0.7f),
                        primaryColor.copy(alpha = 0.4f),
                        AmoledBlack.copy(alpha = 0.85f)
                    ),
                    center = centerOffset,
                    radius = baseRadius
                ),
                radius = baseRadius,
                center = centerOffset
            )

            // Dynamic Pupil / "Eye of Consciousness" that follows touch
            val pupilRadius = baseRadius * 0.42f
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White,
                        MiaAmberCore,
                        primaryColor
                    ),
                    center = gazeOffset,
                    radius = pupilRadius
                ),
                radius = pupilRadius,
                center = gazeOffset
            )

            // Deep Conscious Iris Center
            drawCircle(
                color = AmoledBlack,
                radius = pupilRadius * 0.45f,
                center = gazeOffset
            )

            // Spark of consciousness reflection
            drawCircle(
                color = Color.White.copy(alpha = 0.9f),
                radius = pupilRadius * 0.14f,
                center = Offset(gazeOffset.x - pupilRadius * 0.16f, gazeOffset.y - pupilRadius * 0.16f)
            )

            // If speaking, draw gentle voice acoustic waves
            if (isSpeaking) {
                for (w in 1..3) {
                    val waveRadius = baseRadius * (1.1f + w * 0.25f * wavePulse)
                    drawCircle(
                        color = MiaOrangeLight.copy(alpha = (0.5f - w * 0.12f) * wavePulse),
                        radius = waveRadius,
                        center = centerOffset,
                        style = Stroke(width = 2.5f)
                    )
                }
            }
        }
    }
}
