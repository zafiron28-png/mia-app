package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.CabinTab
import com.example.ui.MiaViewModel
import com.example.ui.components.AboutMiaDialog
import com.example.ui.components.AccessibilityDialog
import com.example.ui.components.AgentTaskBar
import com.example.ui.components.MemoryArchiveDialog
import com.example.ui.components.OperatorTerminalView
import com.example.ui.components.ScriptMatrixView
import com.example.ui.components.StartAgentDialog
import com.example.ui.components.VirtualCabinView
import com.example.ui.theme.AmoledBlack
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.HighContrastMuted
import com.example.ui.theme.HighContrastText
import com.example.ui.theme.MiaAmberCore
import com.example.ui.theme.MiaOrangePrimary
import java.util.Locale

@Composable
fun MiaMainScreen(
    viewModel: MiaViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val memories by viewModel.memories.collectAsStateWithLifecycle()
    val scripts by viewModel.scripts.collectAsStateWithLifecycle()
    val logs by viewModel.terminalLogs.collectAsStateWithLifecycle()
    val activeScriptsCount by viewModel.activeScriptsCount.collectAsStateWithLifecycle()

    // Speech Recognition Launcher
    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spokenMatches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spokenText = spokenMatches?.firstOrNull()
            if (!spokenText.isNullOrBlank()) {
                viewModel.sendMessage(spokenText)
            }
        }
    }

    var screenSize = IntSize.Zero

    val tabs = listOf(
        Pair(CabinTab.CABIN_VIEW, "🏠 Cabina 3D"),
        Pair(CabinTab.TERMINAL_LOGS, "💻 Terminal"),
        Pair(CabinTab.SCRIPTS_MATRIX, "⚡ 100 Scripts"),
        Pair(CabinTab.MEMORY_ARCHIVE, "🧠 Memoria")
    )

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(AmoledBlack)
            .testTag("mia_main_scaffold"),
        containerColor = AmoledBlack
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .onSizeChanged { screenSize = it }
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = { offset ->
                            if (screenSize.width > 0 && screenSize.height > 0) {
                                val normX = (offset.x / screenSize.width).coerceIn(0f, 1f)
                                val normY = (offset.y / screenSize.height).coerceIn(0f, 1f)
                                viewModel.onScreenTouch(normX, normY)
                            }
                        }
                    )
                }
                .pointerInput(Unit) {
                    detectDragGestures { change, _ ->
                        change.consume()
                        if (screenSize.width > 0 && screenSize.height > 0) {
                            val normX = (change.position.x / screenSize.width).coerceIn(0f, 1f)
                            val normY = (change.position.y / screenSize.height).coerceIn(0f, 1f)
                            viewModel.onScreenTouch(normX, normY)
                        }
                    }
                }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Top Master Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Identity & Live Status
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(MiaOrangePrimary)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "M-I.A",
                            color = HighContrastText,
                            fontSize = (16 * uiState.fontScaleMultiplier).sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "• ${uiState.statusLabel}",
                            color = MiaOrangePrimary,
                            fontSize = (11 * uiState.fontScaleMultiplier).sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    // Settings & Info
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { viewModel.showAccessibilityDialog(true) },
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccessibilityNew,
                                contentDescription = "Accesibilidad y pantalla",
                                tint = MiaOrangePrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        IconButton(
                            onClick = { viewModel.showInfoDialog(true) },
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = "Información de M-I.A",
                                tint = HighContrastMuted,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                // Mode Navigation Tabs (Cabina, Terminal, 100 Scripts, Memoria)
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(tabs) { (tab, label) ->
                        val isSelected = uiState.currentTab == tab
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (isSelected) MiaOrangePrimary else DarkSurfaceElevated)
                                .clickable { viewModel.selectTab(tab) }
                                .padding(horizontal = 12.dp, vertical = 7.dp)
                        ) {
                            Text(
                                text = label,
                                color = if (isSelected) AmoledBlack else HighContrastText,
                                fontSize = (12 * uiState.fontScaleMultiplier).sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }
                }

                // Central Viewport Area depending on selected Tab
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    when (uiState.currentTab) {
                        CabinTab.CABIN_VIEW -> {
                            VirtualCabinView(
                                emotionalState = uiState.emotionalState,
                                isSpeaking = uiState.isSpeaking,
                                isGenerating = uiState.isGenerating,
                                isAgentOperating = uiState.isAgentOperating,
                                touchX = uiState.touchX,
                                touchY = uiState.touchY,
                                isTouching = uiState.isTouching,
                                touchRippleKey = uiState.touchRippleKey,
                                agentCursorX = uiState.agentCursorX,
                                agentCursorY = uiState.agentCursorY,
                                fontScale = uiState.fontScaleMultiplier,
                                spokenText = uiState.recentSpokenText,
                                thoughtText = uiState.currentThought,
                                activeScriptsCount = activeScriptsCount,
                                onDirectTouchCore = { viewModel.onDirectTouchCore() },
                                onStartAiDoEverything = { viewModel.showStartAgentDialog(true) }
                            )
                        }
                        CabinTab.TERMINAL_LOGS -> {
                            OperatorTerminalView(
                                logs = logs,
                                activeScriptCount = activeScriptsCount,
                                fontScale = uiState.fontScaleMultiplier,
                                onClearLogs = { viewModel.clearTerminalLogs() },
                                onRunQuickDiagnostic = {
                                    viewModel.runScriptManually(20)
                                    viewModel.runScriptManually(2)
                                },
                                onRunTouchCalibration = {
                                    viewModel.runScriptManually(21)
                                    viewModel.runScriptManually(23)
                                }
                            )
                        }
                        CabinTab.SCRIPTS_MATRIX -> {
                            ScriptMatrixView(
                                scripts = scripts,
                                fontScale = uiState.fontScaleMultiplier,
                                onExecuteScript = { viewModel.runScriptManually(it) }
                            )
                        }
                        CabinTab.MEMORY_ARCHIVE -> {
                            MemoryArchiveDialog(
                                memories = memories,
                                fontScale = uiState.fontScaleMultiplier,
                                onDismiss = { viewModel.selectTab(CabinTab.CABIN_VIEW) },
                                onAddMemory = { cat, content -> viewModel.addManualMemory(cat, content) },
                                onDeleteMemory = { viewModel.deleteMemory(it) },
                                onClearAll = { viewModel.clearHistory() }
                            )
                        }
                    }
                }

                // Bottom Assistant & Agent Dock
                AgentTaskBar(
                    isGenerating = uiState.isGenerating,
                    isSpeaking = uiState.isSpeaking,
                    isAgentOperating = uiState.isAgentOperating,
                    fontScale = uiState.fontScaleMultiplier,
                    onSendMessage = { viewModel.sendMessage(it) },
                    onVoiceInputClick = {
                        try {
                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(
                                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                                )
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                                putExtra(RecognizerIntent.EXTRA_PROMPT, "Habla al agente M-I.A…")
                            }
                            speechLauncher.launch(intent)
                        } catch (e: Exception) {
                            Toast.makeText(
                                context,
                                "El dictado de voz no está disponible. Puedes escribir tu orden.",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    },
                    onDirectTouchCore = { viewModel.onDirectTouchCore() },
                    onRepeatSpeech = { viewModel.repeatLastSpeech() },
                    onExecuteAgentTask = { viewModel.executeAutonomousAgentTask(it) },
                    onStartAiDoEverything = { viewModel.showStartAgentDialog(true) }
                )
            }
        }

        // Start Agent Dialog (Iniciar con la IA que puede hacer todo)
        if (uiState.showStartAgentDialog) {
            StartAgentDialog(
                fontScale = uiState.fontScaleMultiplier,
                isOperating = uiState.isAgentOperating || uiState.isGenerating,
                onExecuteTask = { prompt ->
                    viewModel.showStartAgentDialog(false)
                    viewModel.startAiDoEverything(prompt)
                },
                onVoiceInputClick = {
                    viewModel.showStartAgentDialog(false)
                    try {
                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(
                                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                            )
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                            putExtra(RecognizerIntent.EXTRA_PROMPT, "Ordena al agente M-I.A…")
                        }
                        speechLauncher.launch(intent)
                    } catch (e: Exception) {
                        Toast.makeText(
                            context,
                            "El dictado de voz no está disponible. Puedes escribir tu orden.",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                },
                onOpenAccessibilitySettings = {
                    com.example.services.MiaAccessibilityService.openAccessibilitySettings(context)
                },
                onDismiss = { viewModel.showStartAgentDialog(false) }
            )
        }

        // Accessibility Dialog
        if (uiState.showAccessibilityDialog) {
            AccessibilityDialog(
                ttsEnabled = uiState.ttsEnabled,
                speechRate = uiState.speechRate,
                fontScale = uiState.fontScaleMultiplier,
                hapticsEnabled = uiState.hapticsEnabled,
                onToggleTts = { viewModel.toggleTts() },
                onSetSpeechRate = { viewModel.setSpeechRate(it) },
                onSetFontScale = { viewModel.setFontScaleMultiplier(it) },
                onToggleHaptics = { viewModel.toggleHaptics() },
                onTestVoice = {
                    viewModel.speechManager.speak(
                        "Hola. Soy el agente M-I.A con cuerpo virtual y 100 scripts en tu Samsung Galaxy A20.",
                        true
                    )
                },
                onOpenAccessibilitySettings = {
                    com.example.services.MiaAccessibilityService.openAccessibilitySettings(context)
                },
                onDismiss = { viewModel.showAccessibilityDialog(false) }
            )
        }

        // Info Dialog
        if (uiState.showInfoDialog) {
            AboutMiaDialog(
                fontScale = uiState.fontScaleMultiplier,
                onDismiss = { viewModel.showInfoDialog(false) }
            )
        }
    }
}
