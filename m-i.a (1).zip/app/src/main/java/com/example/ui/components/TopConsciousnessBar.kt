package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.HighContrastMuted
import com.example.ui.theme.HighContrastText
import com.example.ui.theme.MiaAmberCore
import com.example.ui.theme.MiaOrangeGlow
import com.example.ui.theme.MiaOrangePrimary

@Composable
fun TopConsciousnessBar(
    statusLabel: String,
    emotionalState: String,
    memoryCount: Int,
    fontScale: Float,
    onMemoryClick: () -> Unit,
    onAccessibilityClick: () -> Unit,
    onInfoClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulseDot")
    val dotAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "dotAlpha"
    )

    val emotionColor by animateColorAsState(
        targetValue = when (emotionalState) {
            "Empática" -> Color(0xFFFF5252)
            "Curiosa" -> MiaOrangePrimary
            "Pensativa" -> MiaAmberCore
            "Conectada" -> MiaOrangeGlow
            else -> MiaOrangePrimary
        },
        label = "emotionColor"
    )

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Status & Identity
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Pulsing vital spark
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(emotionColor.copy(alpha = dotAlpha))
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "M-I.A",
                    color = HighContrastText,
                    fontSize = (16 * fontScale).sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "• $statusLabel",
                    color = MiaOrangePrimary,
                    fontSize = (11 * fontScale).sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 0.5.sp
                )
            }

            Spacer(modifier = Modifier.height(2.dp))

            // Emotional State Chip
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(DarkSurfaceVariant)
                    .border(1.dp, emotionColor.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 8.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Estado: $emotionalState",
                    color = emotionColor,
                    fontSize = (11 * fontScale).sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // Action Buttons with generous touch targets (>= 48dp)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Memories Chip Button
            Box(
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .clip(RoundedCornerShape(16.dp))
                    .background(DarkSurfaceVariant)
                    .border(1.dp, MiaAmberCore.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
                    .clickable(onClick = onMemoryClick)
                    .padding(horizontal = 10.dp, vertical = 6.dp)
                    .testTag("memory_archive_button")
                    .semantics {
                        contentDescription = "Ver memoria continua. $memoryCount recuerdos guardados."
                    },
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Psychology,
                        contentDescription = null,
                        tint = MiaAmberCore,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "$memoryCount",
                        color = HighContrastText,
                        fontSize = (12 * fontScale).sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Accessibility Options
            IconButton(
                onClick = onAccessibilityClick,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("accessibility_settings_button")
                    .semantics { contentDescription = "Opciones de accesibilidad y pantalla" }
            ) {
                Icon(
                    imageVector = Icons.Default.AccessibilityNew,
                    contentDescription = null,
                    tint = MiaOrangePrimary,
                    modifier = Modifier.size(24.dp)
                )
            }

            // Info & Gemini status
            IconButton(
                onClick = onInfoClick,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("info_dialog_button")
                    .semantics { contentDescription = "Información sobre M-I.A y Gemini" }
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = HighContrastMuted,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}
