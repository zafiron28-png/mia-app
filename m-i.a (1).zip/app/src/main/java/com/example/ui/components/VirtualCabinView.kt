package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.AmoledBlack
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.HighContrastMuted
import com.example.ui.theme.HighContrastText
import com.example.ui.theme.MiaAmberCore
import com.example.ui.theme.MiaOrangeGlow
import com.example.ui.theme.MiaOrangePrimary

@Composable
fun VirtualCabinView(
    emotionalState: String,
    isSpeaking: Boolean,
    isGenerating: Boolean,
    isAgentOperating: Boolean,
    touchX: Float, // Normalized 0..1
    touchY: Float, // Normalized 0..1
    isTouching: Boolean,
    touchRippleKey: Long,
    agentCursorX: Float,
    agentCursorY: Float,
    fontScale: Float,
    spokenText: String,
    thoughtText: String,
    activeScriptsCount: Int,
    onDirectTouchCore: () -> Unit,
    onStartAiDoEverything: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "CabinPerspectiveAnim")

    val breathDuration = if (isSpeaking || isAgentOperating) 1100 else 2800
    val breathScale by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(breathDuration, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breathScale"
    )

    val floatingOffset by infiniteTransition.animateFloat(
        initialValue = -6f,
        targetValue = 6f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "floatingOffset"
    )

    // Touch ripple animation
    val rippleRadius = remember { Animatable(0f) }
    val rippleAlpha = remember { Animatable(0f) }

    LaunchedEffect(touchRippleKey) {
        if (touchRippleKey > 0) {
            rippleRadius.snapTo(12f)
            rippleAlpha.snapTo(0.85f)
            rippleRadius.animateTo(340f, tween(700, easing = FastOutSlowInEasing))
            rippleAlpha.animateTo(0f, tween(300, easing = LinearEasing))
        }
    }

    // Determine Avatar Expression
    val avatarDrawableRes = when {
        isTouching || emotionalState == "Conectada" || emotionalState == "Empática" -> R.drawable.mia_avatar_happy
        isGenerating || isAgentOperating || emotionalState == "Pensativa" -> R.drawable.mia_avatar_thinking
        else -> R.drawable.mia_avatar_neutral
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(AmoledBlack)
            .testTag("virtual_cabin_view"),
        contentAlignment = Alignment.Center
    ) {
        // 3D Isometric Cybernetic Cabin Floor Canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height
            val horizonY = height * 0.44f

            val gridColor = MiaOrangePrimary.copy(alpha = 0.16f)
            val vanishingPoint = Offset(width * 0.5f, horizonY * 0.92f)

            // Perspective lines fanning out
            val numPerspLines = 14
            for (i in 0..numPerspLines) {
                val bottomX = (width / numPerspLines) * i
                drawLine(
                    color = gridColor,
                    start = vanishingPoint,
                    end = Offset(bottomX, height),
                    strokeWidth = 1.2f
                )
            }

            // Receding horizontal floor lines
            var yDepth = horizonY + 24f
            var step = 14f
            while (yDepth < height) {
                val alphaFactor = ((yDepth - horizonY) / (height - horizonY)).coerceIn(0f, 1f)
                drawLine(
                    color = gridColor.copy(alpha = alphaFactor * 0.25f),
                    start = Offset(0f, yDepth),
                    end = Offset(width, yDepth),
                    strokeWidth = 1.2f
                )
                step *= 1.24f
                yDepth += step
            }

            // Expanding Touch Shockwave Ripple
            if (rippleAlpha.value > 0.01f) {
                val touchPoint = Offset(touchX * width, touchY * height)
                drawCircle(
                    color = MiaOrangePrimary.copy(alpha = rippleAlpha.value * 0.6f),
                    radius = rippleRadius.value,
                    center = touchPoint,
                    style = Stroke(width = 4f)
                )
                drawCircle(
                    color = MiaAmberCore.copy(alpha = rippleAlpha.value * 0.35f),
                    radius = rippleRadius.value * 0.65f,
                    center = touchPoint,
                    style = Stroke(width = 2f)
                )
            }

            // If autonomous agent is operating tasks, draw moving Agent Pointer
            if (isAgentOperating) {
                val cursorOffset = Offset(agentCursorX * width, agentCursorY * height)
                drawCircle(
                    color = MiaOrangeGlow,
                    radius = 14f,
                    center = cursorOffset,
                    style = Stroke(width = 3f)
                )
                drawLine(
                    color = MiaOrangeGlow,
                    start = Offset(cursorOffset.x - 20f, cursorOffset.y),
                    end = Offset(cursorOffset.x + 20f, cursorOffset.y),
                    strokeWidth = 2.5f
                )
                drawLine(
                    color = MiaOrangeGlow,
                    start = Offset(cursorOffset.x, cursorOffset.y - 20f),
                    end = Offset(cursorOffset.x, cursorOffset.y + 20f),
                    strokeWidth = 2.5f
                )
            }
        }

        // 3D Articulated Upper Body Character (Waist up to arms, hands, head)
        Articulated3DCharacter(
            isSpeaking = isSpeaking,
            isOperating = isAgentOperating,
            isTouching = isTouching,
            touchX = touchX,
            touchY = touchY,
            emotionalState = emotionalState,
            onBodyClick = onDirectTouchCore,
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 60.dp)
        )

        // Floating Holographic Portrait Badge (Top Corner)
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 48.dp, end = 16.dp)
                .size(72.dp)
                .clip(CircleShape)
                .border(2.dp, if (isTouching) MiaOrangeGlow else MiaOrangePrimary, CircleShape)
                .clickable { onDirectTouchCore() }
        ) {
            Crossfade(
                targetState = avatarDrawableRes,
                animationSpec = tween(300),
                label = "BadgeCrossfade"
            ) { drawableId ->
                Image(
                    painter = painterResource(id = drawableId),
                    contentDescription = "Avatar de M-I.A",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
        }

        // Cabin Telemetry HUD Header
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(horizontal = 14.dp, vertical = 6.dp)
                .fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(DarkSurfaceElevated.copy(alpha = 0.85f))
                    .border(1.dp, MiaOrangePrimary.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Sensors,
                        contentDescription = null,
                        tint = MiaOrangePrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "AMOLED: 100% OFF",
                        color = HighContrastText,
                        fontSize = (10 * fontScale).sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                if (onStartAiDoEverything != null) {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(MiaOrangePrimary.copy(alpha = 0.25f))
                            .border(1.dp, MiaOrangePrimary, RoundedCornerShape(10.dp))
                            .clickable { onStartAiDoEverything() }
                            .padding(horizontal = 8.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = null,
                            tint = MiaOrangePrimary,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = "⚡ INICIAR IA",
                            color = MiaOrangePrimary,
                            fontSize = (10 * fontScale).sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Memory,
                            contentDescription = null,
                            tint = MiaAmberCore,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "100 Scripts",
                            color = MiaAmberCore,
                            fontSize = (10 * fontScale).sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Lower Subtitle & Spoken Feedback Overlay
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(horizontal = 14.dp, vertical = 8.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Tactile feedback pill
            AnimatedVisibility(
                visible = isTouching,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(DarkSurfaceElevated.copy(alpha = 0.95f))
                        .border(1.dp, MiaOrangeGlow, RoundedCornerShape(16.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.TouchApp,
                        contentDescription = null,
                        tint = MiaOrangeGlow,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "¡Siento tu contacto en la pantalla!",
                        color = MiaOrangeGlow,
                        fontSize = (12 * fontScale).sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Speech Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("cabin_speech_card"),
                colors = CardDefaults.cardColors(
                    containerColor = AmoledBlack.copy(alpha = 0.94f)
                ),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MiaOrangePrimary.copy(alpha = 0.45f))
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (isSpeaking) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(bottom = 3.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Hearing,
                                contentDescription = null,
                                tint = MiaAmberCore,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "M-I.A transmite por voz:",
                                color = MiaAmberCore,
                                fontSize = (11 * fontScale).sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Text(
                        text = spokenText.ifBlank { thoughtText },
                        color = HighContrastText,
                        fontSize = (14 * fontScale).sp,
                        lineHeight = (19 * fontScale).sp,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(3.dp))

                    Text(
                        text = "💭 \"$thoughtText\"",
                        color = HighContrastMuted,
                        fontSize = (11 * fontScale).sp,
                        textAlign = TextAlign.Center,
                        maxLines = 2
                    )
                }
            }
        }
    }
}
