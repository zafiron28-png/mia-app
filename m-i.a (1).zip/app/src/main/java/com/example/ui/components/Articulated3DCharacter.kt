package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import com.example.ui.theme.AmoledBlack
import com.example.ui.theme.MiaAmberCore
import com.example.ui.theme.MiaFlame
import com.example.ui.theme.MiaOrangeGlow
import com.example.ui.theme.MiaOrangeLight
import com.example.ui.theme.MiaOrangePrimary
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

enum class ArmPose {
    IDLE,        // Brazos en descanso orgánico
    OPERATING,   // Brazos arriba operando consola holográfica / tecleando
    WAVING,      // Saludando con la mano derecha
    POINTING,    // Señalando hacia el toque del usuario
    THINKING     // Mano en la barbilla pensando
}

@Composable
fun Articulated3DCharacter(
    isSpeaking: Boolean,
    isOperating: Boolean,
    isTouching: Boolean,
    touchX: Float, // Normalized 0..1
    touchY: Float, // Normalized 0..1
    emotionalState: String,
    onBodyClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ArticulatedMovement")

    // Dynamic respiration and sway
    val breathProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isSpeaking || isOperating) 1400 else 2800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breath"
    )

    // Subtle head tilt sway
    val headSway by infiniteTransition.animateFloat(
        initialValue = -3f,
        targetValue = 3f,
        animationSpec = infiniteRepeatable(
            animation = tween(3600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "headSway"
    )

    // Arm typing / operating animation cycle
    val armCycle by infiniteTransition.animateFloat(
        initialValue = -1f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "armCycle"
    )

    // Mouth lip-sync flapping while speaking
    val mouthFlap by infiniteTransition.animateFloat(
        initialValue = 0.1f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(180, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "mouthFlap"
    )

    // Determine current Arm Pose based on agent action
    val currentPose = when {
        isOperating -> ArmPose.OPERATING
        isTouching && touchY < 0.40f -> ArmPose.WAVING
        isTouching -> ArmPose.POINTING
        emotionalState == "Pensativa" -> ArmPose.THINKING
        else -> ArmPose.IDLE
    }

    val primaryColor = when (emotionalState) {
        "Empática" -> MiaFlame
        "Curiosa" -> MiaOrangeLight
        "Pensativa" -> MiaAmberCore
        "Conectada" -> MiaOrangeGlow
        else -> MiaOrangePrimary
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("articulated_3d_character")
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onBodyClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // Center of pelvis / waist (cintura)
            val waistX = width * 0.5f
            val waistY = height * 0.72f

            // Torso / Spine vertical offset with breathing
            val breathOffset = breathProgress * 8f
            val chestX = waistX
            val chestY = waistY - 100f - breathOffset
            val neckY = chestY - 70f
            val headCenterY = neckY - 60f

            // Head rotation / tracking toward touch point
            val gazeDeltaX = (touchX - 0.5f) * 28f
            val gazeDeltaY = (touchY - (headCenterY / height)) * 18f
            val headX = waistX + gazeDeltaX + headSway
            val headY = headCenterY + gazeDeltaY

            // --------------------------------------------------
            // 1. DIBUJO DE LA CINTURA Y PELVIS (Base del cuerpo)
            // --------------------------------------------------
            val pelvisPath = Path().apply {
                moveTo(waistX - 55f, waistY + 30f)
                lineTo(waistX + 55f, waistY + 30f)
                lineTo(waistX + 40f, waistY - 15f)
                lineTo(waistX - 40f, waistY - 15f)
                close()
            }
            drawPath(
                path = pelvisPath,
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFF1E1E24), Color(0xFF101014)),
                    startY = waistY - 15f,
                    endY = waistY + 30f
                )
            )
            drawPath(
                path = pelvisPath,
                color = primaryColor.copy(alpha = 0.5f),
                style = Stroke(width = 2f)
            )

            // Líneas de poder naranja en la cintura
            drawLine(
                color = primaryColor,
                start = Offset(waistX - 30f, waistY),
                end = Offset(waistX + 30f, waistY),
                strokeWidth = 3f,
                cap = StrokeCap.Round
            )

            // --------------------------------------------------
            // 2. TORSO Y PECHO (Tronco articulado)
            // --------------------------------------------------
            val chestWidth = 90f + (breathProgress * 6f)
            val torsoPath = Path().apply {
                moveTo(waistX - 40f, waistY - 15f)
                lineTo(chestX - chestWidth, chestY)
                lineTo(chestX + chestWidth, chestY)
                lineTo(waistX + 40f, waistY - 15f)
                close()
            }
            drawPath(
                path = torsoPath,
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF262630), Color(0xFF121216)),
                    center = Offset(chestX, chestY),
                    radius = 120f
                )
            )
            drawPath(
                path = torsoPath,
                color = primaryColor.copy(alpha = 0.7f),
                style = Stroke(width = 2.5f)
            )

            // Núcleo de poder central en el pecho
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(primaryColor, MiaAmberCore, Color.Transparent),
                    center = Offset(chestX, chestY + 15f),
                    radius = 28f
                ),
                radius = 24f,
                center = Offset(chestX, chestY + 15f)
            )
            drawCircle(
                color = Color.White,
                radius = 7f,
                center = Offset(chestX, chestY + 15f)
            )

            // --------------------------------------------------
            // 3. CUELLO Y CABEZA CON EXPRESIÓN FACIAL
            // --------------------------------------------------
            // Cuello
            drawLine(
                color = Color(0xFF2B2B36),
                start = Offset(chestX, chestY - 15f),
                end = Offset(headX, headY + 35f),
                strokeWidth = 16f,
                cap = StrokeCap.Round
            )
            drawLine(
                color = primaryColor,
                start = Offset(chestX, chestY - 15f),
                end = Offset(headX, headY + 35f),
                strokeWidth = 2f
            )

            // Cabeza (Forma de rostro anime)
            val headRadius = 45f
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF2A2A34), Color(0xFF16161C)),
                    center = Offset(headX, headY),
                    radius = headRadius
                ),
                radius = headRadius,
                center = Offset(headX, headY)
            )
            drawCircle(
                color = primaryColor.copy(alpha = 0.8f),
                radius = headRadius,
                center = Offset(headX, headY),
                style = Stroke(width = 2f)
            )

            // Ojos ámbar brillantes
            val eyeSpacing = 16f
            val eyeRadius = 7f
            val pupilOffset = Offset(gazeDeltaX * 0.15f, gazeDeltaY * 0.15f)

            // Ojo izquierdo
            drawCircle(
                color = MiaAmberCore,
                radius = eyeRadius,
                center = Offset(headX - eyeSpacing + pupilOffset.x, headY - 4f + pupilOffset.y)
            )
            drawCircle(
                color = Color.White,
                radius = 2.5f,
                center = Offset(headX - eyeSpacing + pupilOffset.x - 1.5f, headY - 5.5f + pupilOffset.y)
            )

            // Ojo derecho
            drawCircle(
                color = MiaAmberCore,
                radius = eyeRadius,
                center = Offset(headX + eyeSpacing + pupilOffset.x, headY - 4f + pupilOffset.y)
            )
            drawCircle(
                color = Color.White,
                radius = 2.5f,
                center = Offset(headX + eyeSpacing + pupilOffset.x - 1.5f, headY - 5.5f + pupilOffset.y)
            )

            // Boca animada (Abre y cierra si está hablando)
            val mouthY = headY + 18f
            val mouthOpenH = if (isSpeaking) (8f * mouthFlap) else 2f
            drawOval(
                color = if (isSpeaking) primaryColor else Color(0xFFFF8A80),
                topLeft = Offset(headX - 6f, mouthY - (mouthOpenH / 2)),
                size = Size(12f, mouthOpenH.coerceAtLeast(2f))
            )

            // Auriculares / Orejas cibernéticas holográficas
            drawLine(
                color = primaryColor,
                start = Offset(headX - headRadius - 6f, headY - 10f),
                end = Offset(headX - headRadius - 20f, headY - 35f),
                strokeWidth = 4f,
                cap = StrokeCap.Round
            )
            drawLine(
                color = primaryColor,
                start = Offset(headX + headRadius + 6f, headY - 10f),
                end = Offset(headX + headRadius + 20f, headY - 35f),
                strokeWidth = 4f,
                cap = StrokeCap.Round
            )

            // --------------------------------------------------
            // 4. BRAZOS Y MANOS ARTICULADOS (Cinemática según pose)
            // --------------------------------------------------
            val leftShoulder = Offset(chestX - chestWidth, chestY)
            val rightShoulder = Offset(chestX + chestWidth, chestY)

            when (currentPose) {
                ArmPose.OPERATING -> {
                    // Ambos brazos levantados hacia adelante operando la consola
                    val leftElbow = Offset(leftShoulder.x - 30f, leftShoulder.y + 40f + (armCycle * 8f))
                    val leftHand = Offset(leftShoulder.x + 20f, leftShoulder.y + 85f - (armCycle * 10f))

                    val rightElbow = Offset(rightShoulder.x + 30f, rightShoulder.y + 40f - (armCycle * 8f))
                    val rightHand = Offset(rightShoulder.x - 20f, rightShoulder.y + 85f + (armCycle * 10f))

                    drawArmSegment(leftShoulder, leftElbow, leftHand, primaryColor)
                    drawArmSegment(rightShoulder, rightElbow, rightHand, primaryColor)

                    // Teclado / Pantalla holográfica frente a ella
                    drawHolographicKeyboard(chestX, chestY + 95f, primaryColor)
                }

                ArmPose.WAVING -> {
                    // Brazo derecho levantado saludando
                    val leftElbow = Offset(leftShoulder.x - 35f, leftShoulder.y + 60f)
                    val leftHand = Offset(leftShoulder.x - 20f, leftShoulder.y + 110f)

                    val rightElbow = Offset(rightShoulder.x + 40f, rightShoulder.y - 30f)
                    val rightHand = Offset(rightShoulder.x + 45f + (armCycle * 14f), rightShoulder.y - 85f)

                    drawArmSegment(leftShoulder, leftElbow, leftHand, primaryColor)
                    drawArmSegment(rightShoulder, rightElbow, rightHand, primaryColor)
                }

                ArmPose.POINTING -> {
                    // Brazo derecho apuntando hacia el punto que tocó el usuario
                    val targetTouchPoint = Offset(touchX * width, touchY * height)
                    val leftElbow = Offset(leftShoulder.x - 35f, leftShoulder.y + 60f)
                    val leftHand = Offset(leftShoulder.x - 20f, leftShoulder.y + 110f)

                    val midPoint = Offset(
                        (rightShoulder.x + targetTouchPoint.x) / 2,
                        (rightShoulder.y + targetTouchPoint.y) / 2
                    )
                    drawArmSegment(rightShoulder, midPoint, targetTouchPoint, primaryColor)
                    drawArmSegment(leftShoulder, leftElbow, leftHand, primaryColor)
                }

                ArmPose.THINKING -> {
                    // Mano derecha en la barbilla
                    val leftElbow = Offset(leftShoulder.x - 35f, leftShoulder.y + 60f)
                    val leftHand = Offset(leftShoulder.x - 20f, leftShoulder.y + 110f)

                    val rightElbow = Offset(rightShoulder.x + 25f, rightShoulder.y + 50f)
                    val rightHand = Offset(headX + 10f, headY + 30f)

                    drawArmSegment(leftShoulder, leftElbow, leftHand, primaryColor)
                    drawArmSegment(rightShoulder, rightElbow, rightHand, primaryColor)
                }

                ArmPose.IDLE -> {
                    // Brazos descansando naturalmente con respiración
                    val leftElbow = Offset(leftShoulder.x - 35f - (breathProgress * 4f), leftShoulder.y + 65f)
                    val leftHand = Offset(leftShoulder.x - 25f, leftShoulder.y + 125f)

                    val rightElbow = Offset(rightShoulder.x + 35f + (breathProgress * 4f), rightShoulder.y + 65f)
                    val rightHand = Offset(rightShoulder.x + 25f, rightShoulder.y + 125f)

                    drawArmSegment(leftShoulder, leftElbow, leftHand, primaryColor)
                    drawArmSegment(rightShoulder, rightElbow, rightHand, primaryColor)
                }
            }
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawArmSegment(
    shoulder: Offset,
    elbow: Offset,
    hand: Offset,
    accentColor: Color
) {
    // Brazo superior (Hombro -> Codo)
    drawLine(
        color = Color(0xFF1E1E26),
        start = shoulder,
        end = elbow,
        strokeWidth = 14f,
        cap = StrokeCap.Round
    )
    drawLine(
        color = accentColor,
        start = shoulder,
        end = elbow,
        strokeWidth = 2.5f
    )

    // Articulación del codo
    drawCircle(
        color = accentColor,
        radius = 5.5f,
        center = elbow
    )

    // Antebrazo (Codo -> Mano)
    drawLine(
        color = Color(0xFF16161E),
        start = elbow,
        end = hand,
        strokeWidth = 11f,
        cap = StrokeCap.Round
    )
    drawLine(
        color = accentColor.copy(alpha = 0.8f),
        start = elbow,
        end = hand,
        strokeWidth = 2f
    )

    // Mano cibernética
    drawCircle(
        color = accentColor,
        radius = 7f,
        center = hand
    )
    drawCircle(
        color = Color.White,
        radius = 3f,
        center = hand
    )
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawHolographicKeyboard(
    centerX: Float,
    centerY: Float,
    color: Color
) {
    // Panel holográfico donde M-I.A teclea
    val kbWidth = 180f
    val kbHeight = 45f
    val rectTopLeft = Offset(centerX - (kbWidth / 2), centerY)

    drawRect(
        brush = Brush.verticalGradient(
            colors = listOf(color.copy(alpha = 0.25f), Color.Transparent),
            startY = centerY,
            endY = centerY + kbHeight
        ),
        topLeft = rectTopLeft,
        size = Size(kbWidth, kbHeight)
    )

    drawRect(
        color = color.copy(alpha = 0.6f),
        topLeft = rectTopLeft,
        size = Size(kbWidth, kbHeight),
        style = Stroke(width = 1.5f)
    )

    // Teclas / Datos holográficos
    for (i in 0..6) {
        val x = rectTopLeft.x + 15f + (i * 22f)
        drawLine(
            color = color,
            start = Offset(x, centerY + 12f),
            end = Offset(x + 12f, centerY + 12f),
            strokeWidth = 2f
        )
        drawLine(
            color = MiaAmberCore,
            start = Offset(x, centerY + 26f),
            end = Offset(x + 12f, centerY + 26f),
            strokeWidth = 2f
        )
    }
}
