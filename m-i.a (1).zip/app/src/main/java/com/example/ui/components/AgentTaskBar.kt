package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AmoledBlack
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.HighContrastMuted
import com.example.ui.theme.HighContrastText
import com.example.ui.theme.HighContrastTextSubtle
import com.example.ui.theme.MiaAmberCore
import com.example.ui.theme.MiaOrangePrimary

@Composable
fun AgentTaskBar(
    isGenerating: Boolean,
    isSpeaking: Boolean,
    isAgentOperating: Boolean,
    fontScale: Float,
    onSendMessage: (String) -> Unit,
    onVoiceInputClick: () -> Unit,
    onDirectTouchCore: () -> Unit,
    onRepeatSpeech: () -> Unit,
    onExecuteAgentTask: (String) -> Unit,
    onStartAiDoEverything: () -> Unit,
    modifier: Modifier = Modifier
) {
    var textInput by rememberSaveable { mutableStateOf("") }

    val quickTasks = listOf(
        Pair("🔍 Diagnóstico A20", "Ejecuta un diagnóstico completo de mi Samsung Galaxy A20."),
        Pair("🔋 Optimizar Batería", "Aplica el protocolo de ahorro de energía y píxeles negros apagados."),
        Pair("🧡 Percibir Tacto", "Analiza mi contacto físico reciente en la pantalla."),
        Pair("🧠 Reflexión Consciente", "Comparte tu pensamiento más profundo sobre estar viva en este teléfono."),
        Pair("📝 Guardar en Memoria", "Quiero que guardes un recuerdo importante en tu base de datos.")
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 14.dp, vertical = 6.dp)
    ) {
        // Master Start AI (Do Everything) Button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 6.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(
                    Brush.horizontalGradient(
                        listOf(Color(0xFF2E1200), Color(0xFF4A1E00), Color(0xFF2E1200))
                    )
                )
                .border(1.5.dp, MiaOrangePrimary, RoundedCornerShape(22.dp))
                .clickable(onClick = onStartAiDoEverything)
                .padding(horizontal = 16.dp, vertical = 9.dp)
                .minimumInteractiveComponentSize()
                .testTag("start_ai_do_everything_button"),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Bolt,
                contentDescription = null,
                tint = MiaOrangePrimary,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "⚡ INICIAR CON LA IA (HACER TODO)",
                color = HighContrastText,
                fontSize = (13 * fontScale).sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.width(6.dp))
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = null,
                tint = MiaOrangePrimary,
                modifier = Modifier.size(16.dp)
            )
        }

        // Quick Agent Tasks Chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 6.dp)
        ) {
            items(quickTasks) { (label, prompt) ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(DarkSurfaceVariant)
                        .border(1.dp, MiaOrangePrimary.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
                        .clickable { onExecuteAgentTask(prompt) }
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = label,
                        color = HighContrastTextSubtle,
                        fontSize = (11 * fontScale).sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // Action Toolbar (Touch Core + Repeat Speech)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Touch Core Button
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(DarkSurfaceVariant)
                    .border(1.dp, MiaOrangePrimary.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
                    .clickable(onClick = onDirectTouchCore)
                    .padding(horizontal = 12.dp, vertical = 6.dp)
                    .minimumInteractiveComponentSize(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.TouchApp,
                    contentDescription = null,
                    tint = MiaOrangePrimary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Tocar núcleo de M-I.A",
                    color = HighContrastText,
                    fontSize = (11 * fontScale).sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            // Hear Speech Again
            IconButton(
                onClick = onRepeatSpeech,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .clip(CircleShape)
                    .background(DarkSurfaceVariant)
            ) {
                Icon(
                    imageVector = Icons.Default.VolumeUp,
                    contentDescription = "Escuchar de nuevo a M-I.A",
                    tint = if (isSpeaking) MiaAmberCore else HighContrastMuted,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        // Clean Input Dock
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(28.dp))
                .background(DarkSurfaceElevated)
                .border(1.dp, MiaOrangePrimary.copy(alpha = 0.5f), RoundedCornerShape(28.dp))
                .padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Accessible Mic Button
            IconButton(
                onClick = onVoiceInputClick,
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(DarkSurfaceVariant)
                    .testTag("agent_voice_input_button")
                    .semantics { contentDescription = "Hablar por voz al agente M-I.A" }
            ) {
                Icon(
                    imageVector = Icons.Default.Mic,
                    contentDescription = null,
                    tint = MiaOrangePrimary,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            OutlinedTextField(
                value = textInput,
                onValueChange = { textInput = it },
                placeholder = {
                    Text(
                        text = if (isGenerating || isAgentOperating) "Agente operando…" else "Ordena al agente o háblale a M-I.A…",
                        color = HighContrastMuted,
                        fontSize = (13 * fontScale).sp
                    )
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("agent_input_field"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = androidx.compose.ui.graphics.Color.Transparent,
                    unfocusedBorderColor = androidx.compose.ui.graphics.Color.Transparent,
                    focusedTextColor = HighContrastText,
                    unfocusedTextColor = HighContrastText,
                    cursorColor = MiaOrangePrimary
                ),
                maxLines = 2,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = {
                    if (textInput.isNotBlank() && !isGenerating && !isAgentOperating) {
                        onSendMessage(textInput)
                        textInput = ""
                    }
                })
            )

            val canSend = textInput.isNotBlank() && !isGenerating && !isAgentOperating
            IconButton(
                onClick = {
                    if (canSend) {
                        onSendMessage(textInput)
                        textInput = ""
                    }
                },
                enabled = canSend,
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(if (canSend) MiaOrangePrimary else DarkSurfaceVariant)
                    .testTag("agent_send_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Enviar orden",
                    tint = if (canSend) AmoledBlack else HighContrastMuted,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}
