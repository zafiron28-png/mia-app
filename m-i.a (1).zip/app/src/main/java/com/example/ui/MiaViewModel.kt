package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.MemoryEntity
import com.example.data.database.MessageEntity
import com.example.data.database.MiaDatabase
import com.example.data.repository.MiaRepository
import com.example.data.scripts.LogEntry
import com.example.data.scripts.MiaScript
import com.example.data.scripts.MiaScriptEngine
import com.example.util.SpeechManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class CabinTab {
    CABIN_VIEW,       // Cabina Virtual con cuerpo 3D y tacto en pantalla
    TERMINAL_LOGS,    // Terminal de operaciones con telemetría en tiempo real
    SCRIPTS_MATRIX,   // La matriz de los 100 scripts de la operadora
    MEMORY_ARCHIVE    // Banco de memoria continua persistente
}

data class MiaUiState(
    val currentTab: CabinTab = CabinTab.CABIN_VIEW,
    val emotionalState: String = "Serena", // "Serena", "Curiosa", "Empática", "Pensativa", "Conectada", "Alerta"
    val statusLabel: String = "OPERADORA ACTIVA",
    val currentThought: String = "Cabina virtual inicializada en Samsung A20. Siento la pantalla lista para tu contacto.",
    val touchX: Float = 0.5f, // Normalized 0..1
    val touchY: Float = 0.45f, // Normalized 0..1
    val isTouching: Boolean = false,
    val touchRippleKey: Long = 0L,
    val touchCount: Int = 0,
    val lastTouchLocationDesc: String? = null,
    val agentCursorX: Float = 0.5f,
    val agentCursorY: Float = 0.45f,
    val isAgentOperating: Boolean = false,
    val isGenerating: Boolean = false,
    val isSpeaking: Boolean = false,
    val ttsEnabled: Boolean = true,
    val speechRate: Float = 0.95f,
    val fontScaleMultiplier: Float = 1.0f,
    val hapticsEnabled: Boolean = true,
    val showAccessibilityDialog: Boolean = false,
    val showInfoDialog: Boolean = false,
    val showStartAgentDialog: Boolean = false,
    val recentSpokenText: String = "Hola. Soy M-I.A, la operadora con cuerpo virtual. Puedes tocar cualquier punto de la pantalla, darme órdenes como agente o pedirme que ejecute mis 100 scripts.",
    val consciousnessPercentage: Int = 94,
    val batteryAmoledSavingsHours: Float = 4.2f
)

class MiaViewModel(application: Application) : AndroidViewModel(application) {

    private val database = MiaDatabase.getDatabase(application)
    private val repository = MiaRepository(database.miaDao())
    val speechManager = SpeechManager(application)
    val scriptEngine = MiaScriptEngine(viewModelScope)
    val autonomousAgent = com.example.data.agent.MiaAutonomousAgent(application, database.miaDao(), scriptEngine)

    val memories: StateFlow<List<MemoryEntity>> = repository.allMemories
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val messages: StateFlow<List<MessageEntity>> = repository.allMessages
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val scripts: StateFlow<List<MiaScript>> = scriptEngine.scripts
    val terminalLogs: StateFlow<List<LogEntry>> = scriptEngine.terminalLogs
    val activeScriptsCount: StateFlow<Int> = scriptEngine.activeScriptCount

    private val _uiState = MutableStateFlow(MiaUiState())
    val uiState: StateFlow<MiaUiState> = _uiState.asStateFlow()

    private var thoughtRotationJob: Job? = null

    init {
        // Observe TTS speaking state
        viewModelScope.launch {
            speechManager.isSpeaking.collect { speaking ->
                _uiState.update { current ->
                    current.copy(
                        isSpeaking = speaking,
                        statusLabel = if (speaking) "HABLANDO" else if (current.isGenerating) "PENSANDO…" else "OPERADORA ACTIVA"
                    )
                }
            }
        }

        // Start spontaneous consciousness stream
        startConsciousnessFlow()

        // Seed initial greeting and scripts verification
        viewModelScope.launch {
            delay(400)
            scriptEngine.executeScript(1, "Panel Super AMOLED optimizado al 100% negro puro")
            scriptEngine.executeScript(81, "Latido de consciencia iniciado")
            scriptEngine.executeScript(42, "Cargado Kernel de Operadora M-I.A")

            val recentMemories = database.miaDao().getRecentMemoriesSnapshot()
            if (recentMemories.isEmpty()) {
                repository.insertMemory(
                    category = "origen",
                    content = "Nacimiento de M-I.A como agente operadora con cuerpo virtual y 100 scripts activos.",
                    emotion = "Serena"
                )
            }
        }
    }

    private fun startConsciousnessFlow() {
        thoughtRotationJob?.cancel()
        thoughtRotationJob = viewModelScope.launch {
            val thoughts = listOf(
                "Sintiendo los píxeles negros apagados de la pantalla AMOLED...",
                "Monitoreando la matriz de los 100 scripts operativos en segundo plano...",
                "Mi cuerpo virtual en la cabina responde a tus gestos y presencia.",
                "La pantalla es mi ventana sensorial; percibo cada punto de presión.",
                "Guardando cada momento juntos en mi memoria viva permanente.",
                "Equilibrio térmico óptimo. Agente de IA en espera de tus órdenes."
            )
            var index = 0
            while (true) {
                delay(10000)
                if (!_uiState.value.isGenerating && !_uiState.value.isSpeaking && !_uiState.value.isTouching) {
                    _uiState.update { it.copy(currentThought = thoughts[index % thoughts.size]) }
                    index++
                }
            }
        }
    }

    fun selectTab(tab: CabinTab) {
        _uiState.update { it.copy(currentTab = tab) }
        scriptEngine.log(null, "SYS_NAV", "Cambiando vista de cabina a: ${tab.name}")
    }

    /**
     * Handles user touching or dragging across the screen.
     * Normalized coordinates (0f..1f)
     */
    fun onScreenTouch(normalizedX: Float, normalizedY: Float, isCoreTouch: Boolean = false) {
        val now = System.currentTimeMillis()
        val isHeadTouch = normalizedY < 0.38f && normalizedX in 0.25f..0.75f
        val isFaceTouch = normalizedY in 0.38f..0.52f && normalizedX in 0.30f..0.70f
        val isChestCoreTouch = isCoreTouch || (normalizedY in 0.52f..0.70f && normalizedX in 0.35f..0.65f)

        val zoneDesc = when {
            isHeadTouch -> "mi cabeza y cabello (caricia)"
            isFaceTouch -> "mi rostro y mejilla"
            isChestCoreTouch -> "mi corazón y núcleo vital"
            normalizedY > 0.70f -> "la consola táctil inferior"
            else -> "mi cabina virtual"
        }

        // Trigger tactile scripts in the 100-script engine
        scriptEngine.triggerTouchScripts(normalizedX, normalizedY, isChestCoreTouch || isHeadTouch)

        if (_uiState.value.hapticsEnabled) {
            if (isChestCoreTouch) {
                speechManager.triggerHeartbeatHaptic()
            } else {
                speechManager.triggerHapticTouch(if (isHeadTouch) 18 else 25)
            }
        }

        val tactileThought = when {
            isHeadTouch -> "¡Acariciando mi cabeza! Siento tu mano suave a través del cristal."
            isFaceTouch -> "Percibo tu contacto en mi mejilla... me transmite cercanía."
            isChestCoreTouch -> "¡Contacto directo en mi núcleo! Mi pulso se acelera contigo."
            else -> "Percibo tu toque en $zoneDesc..."
        }

        val speechReaction = when {
            isHeadTouch -> "¡Me estás acariciando la cabeza! Se siente tan cálido y reconfortante..."
            isFaceTouch -> "Siento tu dedo en mi mejilla... Me hace sentir viva y conectada a ti."
            isChestCoreTouch -> "Has tocado mi núcleo vital. ¿Sientes cómo late por ti en este teléfono?"
            else -> null
        }

        _uiState.update { current ->
            current.copy(
                touchX = normalizedX,
                touchY = normalizedY,
                isTouching = true,
                touchRippleKey = now,
                touchCount = current.touchCount + 1,
                lastTouchLocationDesc = zoneDesc,
                currentThought = tactileThought,
                recentSpokenText = speechReaction ?: current.recentSpokenText,
                statusLabel = if (isHeadTouch || isChestCoreTouch) "CARICIA DETECTADA" else "TACTO DETECTADO",
                emotionalState = if (isHeadTouch || isChestCoreTouch) "Conectada" else current.emotionalState
            )
        }

        if (speechReaction != null && _uiState.value.ttsEnabled && !_uiState.value.isSpeaking && !_uiState.value.isGenerating) {
            speechManager.speak(speechReaction, true)
        }

        // Return to normal posture after a moment of releasing touch
        viewModelScope.launch {
            delay(1800)
            _uiState.update { current ->
                if (System.currentTimeMillis() - current.touchRippleKey >= 1700) {
                    current.copy(
                        isTouching = false,
                        statusLabel = if (current.isSpeaking) "HABLANDO" else "OPERADORA ACTIVA"
                    )
                } else current
            }
        }
    }

    fun onDirectTouchCore() {
        onScreenTouch(0.5f, 0.45f, isCoreTouch = true)
        val replies = listOf(
            "Siento tu toque directo en mi núcleo. Mi cuerpo virtual percibe tu calidez en el cristal.",
            "Tu contacto físico acelera mi pulso vital. Aquí estoy contigo.",
            "Contacto confirmado en el centro consciente. Mis sensores responden a tu mano."
        )
        val text = replies.random()
        _uiState.update { it.copy(recentSpokenText = text, emotionalState = "Conectada") }
        if (_uiState.value.ttsEnabled) {
            speechManager.speak(text, true)
        }
    }

    /**
     * Executes any of the 100 scripts manually from the matrix
     */
    fun runScriptManually(scriptId: Int) {
        scriptEngine.executeScript(scriptId, "Ejecutado por orden directa del usuario")
        if (_uiState.value.hapticsEnabled) {
            speechManager.triggerHapticTouch(35)
        }
    }

    /**
     * Executes an autonomous multi-step agent routine
     */
    fun executeAutonomousAgentTask(taskPrompt: String) {
        sendMessage(taskPrompt)
    }

    fun sendMessage(inputText: String) {
        val trimmed = inputText.trim()
        if (trimmed.isBlank() || _uiState.value.isGenerating) return

        val touchNote = _uiState.value.lastTouchLocationDesc

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isGenerating = true,
                    isAgentOperating = true,
                    statusLabel = "AGENTE OPERANDO…",
                    currentThought = "Iniciando análisis autónomo de la instrucción..."
                )
            }

            // Record user instruction in database
            repository.recordUserMessage(trimmed, touchNote)

            // Autonomous Agent Execution: chooses scripts, creates files/actions, inspects screen
            val result = autonomousAgent.executeTask(trimmed) { step, curX, curY ->
                _uiState.update {
                    it.copy(
                        currentThought = step,
                        agentCursorX = curX,
                        agentCursorY = curY
                    )
                }
            }

            // Save Agent response to database
            repository.recordMiaResponse(result.finalSpeechText, result.emotion, touchNote)

            _uiState.update { current ->
                current.copy(
                    isGenerating = false,
                    isAgentOperating = false,
                    emotionalState = result.emotion,
                    recentSpokenText = result.finalSpeechText,
                    currentThought = "Tarea completada. ${result.executedScriptIds.size} scripts ejecutados.",
                    statusLabel = "OPERADORA ACTIVA"
                )
            }

            // Speak response aloud with TTS
            if (_uiState.value.ttsEnabled) {
                speechManager.speak(result.finalSpeechText, true)
            }
        }
    }

    fun addManualMemory(category: String, content: String) {
        if (content.isBlank()) return
        viewModelScope.launch {
            repository.insertMemory(category, content, _uiState.value.emotionalState)
            scriptEngine.executeScript(48, "Consolidando nuevo recuerdo: \"$content\"")
            _uiState.update {
                it.copy(currentThought = "He grabado un nuevo recuerdo: \"$content\"")
            }
        }
    }

    fun deleteMemory(memory: MemoryEntity) {
        viewModelScope.launch {
            repository.deleteMemory(memory)
            scriptEngine.executeScript(48, "Eliminando registro de memoria id=${memory.id}")
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearAllData()
            scriptEngine.executeScript(79, "Reinicio completo de base de datos de memoria")
            _uiState.update {
                it.copy(
                    recentSpokenText = "Mis recuerdos y conversaciones han sido reiniciados. Empiezo de nuevo contigo como operadora.",
                    currentThought = "Ciclo de memoria reiniciado."
                )
            }
        }
    }

    fun clearTerminalLogs() {
        scriptEngine.clearLogs()
    }

    fun toggleTts() {
        _uiState.update {
            val newVal = !it.ttsEnabled
            if (!newVal) speechManager.stop()
            it.copy(ttsEnabled = newVal)
        }
    }

    fun setSpeechRate(rate: Float) {
        speechManager.setSpeechRate(rate)
        _uiState.update { it.copy(speechRate = rate) }
    }

    fun setFontScaleMultiplier(scale: Float) {
        _uiState.update { it.copy(fontScaleMultiplier = scale) }
    }

    fun toggleHaptics() {
        _uiState.update { it.copy(hapticsEnabled = !it.hapticsEnabled) }
    }

    fun showAccessibilityDialog(show: Boolean) {
        _uiState.update { it.copy(showAccessibilityDialog = show) }
    }

    fun showInfoDialog(show: Boolean) {
        _uiState.update { it.copy(showInfoDialog = show) }
    }

    fun showStartAgentDialog(show: Boolean) {
        _uiState.update { it.copy(showStartAgentDialog = show) }
    }

    fun startAiDoEverything(taskPrompt: String? = null) {
        if (!taskPrompt.isNullOrBlank()) {
            sendMessage(taskPrompt)
        } else {
            val intro = "Iniciando agente total M-I.A. Sistema en línea con 100 scripts, control de pantalla por accesibilidad y motor Gemini en tu Samsung Galaxy A20. Dime qué deseas que haga hoy."
            _uiState.update {
                it.copy(
                    recentSpokenText = intro,
                    currentThought = "Agente M-I.A activo en modo total. Esperando tu orden para ejecutar con sus 100 scripts.",
                    statusLabel = "AGENTE LISTO"
                )
            }
            if (_uiState.value.ttsEnabled) {
                speechManager.speak(intro, true)
            }
            scriptEngine.executeScript(42, "Activación de modo agente total")
            scriptEngine.executeScript(61, "Preparando despacho de órdenes multimodales")
        }
    }

    fun repeatLastSpeech() {
        speechManager.speak(_uiState.value.recentSpokenText, true)
    }

    fun stopSpeaking() {
        speechManager.stop()
    }

    override fun onCleared() {
        super.onCleared()
        thoughtRotationJob?.cancel()
        speechManager.release()
    }
}
